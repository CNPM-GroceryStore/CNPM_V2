﻿namespace GroceryStore
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            ordersPage = new Guna.UI2.WinForms.Guna2GradientButton();
            homepage = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            mgmProductPage = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            pn_choice = new Panel();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            pn_addProduct = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            pn_orders = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_orders = new Guna.UI2.WinForms.Guna2DataGridView();
            panel5 = new Panel();
            label9 = new Label();
            txb_shipment = new Guna.UI2.WinForms.Guna2TextBox();
            ptb_addImagePro = new PictureBox();
            btn_upload = new Guna.UI2.WinForms.Guna2Button();
            label8 = new Label();
            guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            label7 = new Label();
            dtp_addPro = new Guna.UI2.WinForms.Guna2DateTimePicker();
            btn_comfirm = new Guna.UI2.WinForms.Guna2GradientButton();
            label6 = new Label();
            txb_addType = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            txb_addPrice = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            txb_addAmount = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            txb_addNamePro = new Guna.UI2.WinForms.Guna2TextBox();
            pn_mgmProduct = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            pt_searchPro = new PictureBox();
            txb_searchProduct = new Guna.UI2.WinForms.Guna2TextBox();
            btn_addProduct = new Guna.UI2.WinForms.Guna2Button();
            panel4 = new Panel();
            dgv_mgmProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            lb_titilePage = new Label();
            pn_homepage = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            panel3 = new Panel();
            dgv_order = new Guna.UI2.WinForms.Guna2DataGridView();
            label4 = new Label();
            pn_total_month = new Guna.UI2.WinForms.Guna2GradientPanel();
            lb_turnover_month = new Label();
            label2 = new Label();
            pn_chart = new Panel();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            lb_nameUser2 = new Label();
            pictureBox3 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            pn_addProduct.SuspendLayout();
            pn_orders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_orders).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptb_addImagePro).BeginInit();
            pn_mgmProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pt_searchPro).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_mgmProduct).BeginInit();
            pn_homepage.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_order).BeginInit();
            pn_total_month.SuspendLayout();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(guna2GradientButton7);
            panel1.Controls.Add(ordersPage);
            panel1.Controls.Add(homepage);
            panel1.Controls.Add(guna2GradientButton4);
            panel1.Controls.Add(guna2GradientButton2);
            panel1.Controls.Add(mgmProductPage);
            panel1.Controls.Add(guna2GradientButton1);
            panel1.Controls.Add(pn_choice);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(202, 845);
            panel1.TabIndex = 6;
            // 
            // guna2GradientButton7
            // 
            guna2GradientButton7.CustomizableEdges = customizableEdges1;
            guna2GradientButton7.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton7.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton7.FillColor = Color.White;
            guna2GradientButton7.FillColor2 = Color.White;
            guna2GradientButton7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2GradientButton7.ForeColor = Color.Black;
            guna2GradientButton7.Image = (Image)resources.GetObject("guna2GradientButton7.Image");
            guna2GradientButton7.ImageAlign = HorizontalAlignment.Left;
            guna2GradientButton7.Location = new Point(6, 488);
            guna2GradientButton7.Name = "guna2GradientButton7";
            guna2GradientButton7.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientButton7.Size = new Size(182, 53);
            guna2GradientButton7.TabIndex = 13;
            guna2GradientButton7.Text = "Nhà cung cấp";
            // 
            // ordersPage
            // 
            ordersPage.CustomizableEdges = customizableEdges3;
            ordersPage.DisabledState.BorderColor = Color.DarkGray;
            ordersPage.DisabledState.CustomBorderColor = Color.DarkGray;
            ordersPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ordersPage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            ordersPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ordersPage.FillColor = Color.White;
            ordersPage.FillColor2 = Color.White;
            ordersPage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            ordersPage.ForeColor = Color.Black;
            ordersPage.Image = (Image)resources.GetObject("ordersPage.Image");
            ordersPage.ImageAlign = HorizontalAlignment.Left;
            ordersPage.Location = new Point(6, 193);
            ordersPage.Name = "ordersPage";
            ordersPage.ShadowDecoration.CustomizableEdges = customizableEdges4;
            ordersPage.Size = new Size(182, 53);
            ordersPage.TabIndex = 12;
            ordersPage.Text = "Đơn hàng";
            ordersPage.Click += ordersPage_Click;
            // 
            // homepage
            // 
            homepage.CustomizableEdges = customizableEdges5;
            homepage.DisabledState.BorderColor = Color.DarkGray;
            homepage.DisabledState.CustomBorderColor = Color.DarkGray;
            homepage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            homepage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            homepage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            homepage.FillColor = Color.White;
            homepage.FillColor2 = Color.White;
            homepage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            homepage.ForeColor = Color.Black;
            homepage.Image = (Image)resources.GetObject("homepage.Image");
            homepage.ImageAlign = HorizontalAlignment.Left;
            homepage.Location = new Point(6, 134);
            homepage.Name = "homepage";
            homepage.ShadowDecoration.CustomizableEdges = customizableEdges6;
            homepage.Size = new Size(182, 53);
            homepage.TabIndex = 11;
            homepage.Text = "Trang chủ";
            homepage.Click += homepage_Click;
            // 
            // guna2GradientButton4
            // 
            guna2GradientButton4.CustomizableEdges = customizableEdges7;
            guna2GradientButton4.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton4.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton4.FillColor = Color.White;
            guna2GradientButton4.FillColor2 = Color.White;
            guna2GradientButton4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2GradientButton4.ForeColor = Color.Black;
            guna2GradientButton4.Image = (Image)resources.GetObject("guna2GradientButton4.Image");
            guna2GradientButton4.ImageAlign = HorizontalAlignment.Left;
            guna2GradientButton4.Location = new Point(6, 252);
            guna2GradientButton4.Name = "guna2GradientButton4";
            guna2GradientButton4.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2GradientButton4.Size = new Size(182, 53);
            guna2GradientButton4.TabIndex = 10;
            guna2GradientButton4.Text = "In hóa đơn";
            // 
            // guna2GradientButton2
            // 
            guna2GradientButton2.CustomizableEdges = customizableEdges9;
            guna2GradientButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton2.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton2.FillColor = Color.White;
            guna2GradientButton2.FillColor2 = Color.White;
            guna2GradientButton2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2GradientButton2.ForeColor = Color.Black;
            guna2GradientButton2.Image = (Image)resources.GetObject("guna2GradientButton2.Image");
            guna2GradientButton2.ImageAlign = HorizontalAlignment.Left;
            guna2GradientButton2.Location = new Point(6, 311);
            guna2GradientButton2.Name = "guna2GradientButton2";
            guna2GradientButton2.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2GradientButton2.Size = new Size(182, 53);
            guna2GradientButton2.TabIndex = 9;
            guna2GradientButton2.Text = "Thống kê";
            // 
            // mgmProductPage
            // 
            mgmProductPage.CustomizableEdges = customizableEdges11;
            mgmProductPage.DisabledState.BorderColor = Color.DarkGray;
            mgmProductPage.DisabledState.CustomBorderColor = Color.DarkGray;
            mgmProductPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            mgmProductPage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            mgmProductPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            mgmProductPage.FillColor = Color.White;
            mgmProductPage.FillColor2 = Color.White;
            mgmProductPage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            mgmProductPage.ForeColor = Color.Black;
            mgmProductPage.Image = (Image)resources.GetObject("mgmProductPage.Image");
            mgmProductPage.ImageAlign = HorizontalAlignment.Left;
            mgmProductPage.Location = new Point(6, 370);
            mgmProductPage.Name = "mgmProductPage";
            mgmProductPage.ShadowDecoration.CustomizableEdges = customizableEdges12;
            mgmProductPage.Size = new Size(182, 53);
            mgmProductPage.TabIndex = 8;
            mgmProductPage.Text = "Quản lí sản phẩm";
            mgmProductPage.Click += mgmProductPage_Click;
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges13;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.White;
            guna2GradientButton1.FillColor2 = Color.White;
            guna2GradientButton1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2GradientButton1.ForeColor = Color.Black;
            guna2GradientButton1.Image = (Image)resources.GetObject("guna2GradientButton1.Image");
            guna2GradientButton1.ImageAlign = HorizontalAlignment.Left;
            guna2GradientButton1.Location = new Point(6, 429);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2GradientButton1.Size = new Size(182, 53);
            guna2GradientButton1.TabIndex = 6;
            guna2GradientButton1.Text = "Quản lí khách hàng";
            // 
            // pn_choice
            // 
            pn_choice.BackColor = Color.Red;
            pn_choice.Location = new Point(189, 134);
            pn_choice.Name = "pn_choice";
            pn_choice.Size = new Size(10, 53);
            pn_choice.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_home;
            pictureBox1.Location = new Point(36, 4);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 133);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(248, 9, 9);
            panel2.Controls.Add(pn_orders);
            panel2.Controls.Add(pn_addProduct);
            panel2.Controls.Add(pn_mgmProduct);
            panel2.Controls.Add(lb_titilePage);
            panel2.Controls.Add(pn_homepage);
            panel2.Controls.Add(guna2Panel1);
            panel2.Location = new Point(208, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1011, 841);
            panel2.TabIndex = 7;
            // 
            // pn_addProduct
            // 
            pn_addProduct.BorderRadius = 30;
            pn_addProduct.BorderThickness = 1;
            pn_addProduct.Controls.Add(panel5);
            pn_addProduct.CustomizableEdges = customizableEdges35;
            pn_addProduct.Location = new Point(24, 100);
            pn_addProduct.Name = "pn_addProduct";
            pn_addProduct.ShadowDecoration.CustomizableEdges = customizableEdges36;
            pn_addProduct.Size = new Size(968, 725);
            pn_addProduct.TabIndex = 15;
            pn_addProduct.Visible = false;
            // 
            // pn_orders
            // 
            pn_orders.BorderRadius = 30;
            pn_orders.BorderThickness = 1;
            pn_orders.Controls.Add(dgv_orders);
            pn_orders.CustomizableEdges = customizableEdges15;
            pn_orders.Location = new Point(24, 100);
            pn_orders.Name = "pn_orders";
            pn_orders.ShadowDecoration.CustomizableEdges = customizableEdges16;
            pn_orders.Size = new Size(968, 725);
            pn_orders.TabIndex = 16;
            pn_orders.Visible = false;
            // 
            // dgv_orders
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv_orders.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv_orders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv_orders.ColumnHeadersHeight = 50;
            dgv_orders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.White;
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv_orders.DefaultCellStyle = dataGridViewCellStyle3;
            dgv_orders.GridColor = Color.FromArgb(231, 229, 255);
            dgv_orders.Location = new Point(25, 52);
            dgv_orders.Name = "dgv_orders";
            dgv_orders.RowHeadersVisible = false;
            dgv_orders.RowHeadersWidth = 51;
            dgv_orders.RowTemplate.Height = 29;
            dgv_orders.Size = new Size(918, 621);
            dgv_orders.TabIndex = 2;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_orders.ThemeStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_orders.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_orders.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_orders.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_orders.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_orders.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_orders.ThemeStyle.HeaderStyle.Height = 50;
            dgv_orders.ThemeStyle.ReadOnly = false;
            dgv_orders.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_orders.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_orders.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_orders.ThemeStyle.RowsStyle.Height = 29;
            dgv_orders.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_orders.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label9);
            panel5.Controls.Add(txb_shipment);
            panel5.Controls.Add(ptb_addImagePro);
            panel5.Controls.Add(btn_upload);
            panel5.Controls.Add(label8);
            panel5.Controls.Add(guna2GradientButton8);
            panel5.Controls.Add(label7);
            panel5.Controls.Add(dtp_addPro);
            panel5.Controls.Add(btn_comfirm);
            panel5.Controls.Add(label6);
            panel5.Controls.Add(txb_addType);
            panel5.Controls.Add(label5);
            panel5.Controls.Add(txb_addPrice);
            panel5.Controls.Add(label3);
            panel5.Controls.Add(txb_addAmount);
            panel5.Controls.Add(label1);
            panel5.Controls.Add(txb_addNamePro);
            panel5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            panel5.Location = new Point(36, 82);
            panel5.Name = "panel5";
            panel5.Size = new Size(908, 536);
            panel5.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(694, 49);
            label9.Name = "label9";
            label9.Size = new Size(82, 28);
            label9.TabIndex = 17;
            label9.Text = "Lô hàng";
            // 
            // txb_shipment
            // 
            txb_shipment.BorderColor = Color.Black;
            txb_shipment.BorderRadius = 10;
            txb_shipment.CustomizableEdges = customizableEdges17;
            txb_shipment.DefaultText = "";
            txb_shipment.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_shipment.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_shipment.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_shipment.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_shipment.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_shipment.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_shipment.ForeColor = Color.Black;
            txb_shipment.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_shipment.Location = new Point(694, 83);
            txb_shipment.Name = "txb_shipment";
            txb_shipment.PasswordChar = '\0';
            txb_shipment.PlaceholderText = "";
            txb_shipment.SelectedText = "";
            txb_shipment.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txb_shipment.Size = new Size(151, 45);
            txb_shipment.TabIndex = 16;
            // 
            // ptb_addImagePro
            // 
            ptb_addImagePro.Location = new Point(517, 326);
            ptb_addImagePro.Name = "ptb_addImagePro";
            ptb_addImagePro.Size = new Size(151, 97);
            ptb_addImagePro.TabIndex = 15;
            ptb_addImagePro.TabStop = false;
            // 
            // btn_upload
            // 
            btn_upload.BorderRadius = 10;
            btn_upload.CustomizableEdges = customizableEdges19;
            btn_upload.DisabledState.BorderColor = Color.DarkGray;
            btn_upload.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_upload.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_upload.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_upload.FillColor = Color.FromArgb(254, 72, 72);
            btn_upload.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_upload.ForeColor = Color.White;
            btn_upload.Location = new Point(694, 345);
            btn_upload.Name = "btn_upload";
            btn_upload.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btn_upload.Size = new Size(151, 47);
            btn_upload.TabIndex = 14;
            btn_upload.Text = "Upload Image";
            btn_upload.Click += upload_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(517, 295);
            label8.Name = "label8";
            label8.Size = new Size(90, 28);
            label8.TabIndex = 13;
            label8.Text = "Hình ảnh";
            // 
            // guna2GradientButton8
            // 
            guna2GradientButton8.BorderRadius = 10;
            guna2GradientButton8.CustomizableEdges = customizableEdges21;
            guna2GradientButton8.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton8.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton8.FillColor = Color.LightGray;
            guna2GradientButton8.FillColor2 = Color.LightGray;
            guna2GradientButton8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            guna2GradientButton8.ForeColor = Color.Black;
            guna2GradientButton8.Location = new Point(62, 438);
            guna2GradientButton8.Name = "guna2GradientButton8";
            guna2GradientButton8.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2GradientButton8.Size = new Size(108, 56);
            guna2GradientButton8.TabIndex = 11;
            guna2GradientButton8.Text = "Hủy";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(62, 184);
            label7.Name = "label7";
            label7.Size = new Size(123, 28);
            label7.TabIndex = 10;
            label7.Text = "Hạn sử dụng";
            // 
            // dtp_addPro
            // 
            dtp_addPro.BorderRadius = 10;
            dtp_addPro.Checked = true;
            dtp_addPro.CustomizableEdges = customizableEdges23;
            dtp_addPro.FillColor = Color.White;
            dtp_addPro.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dtp_addPro.Format = DateTimePickerFormat.Short;
            dtp_addPro.Location = new Point(62, 217);
            dtp_addPro.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtp_addPro.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtp_addPro.Name = "dtp_addPro";
            dtp_addPro.ShadowDecoration.CustomizableEdges = customizableEdges24;
            dtp_addPro.Size = new Size(328, 45);
            dtp_addPro.TabIndex = 9;
            dtp_addPro.Value = new DateTime(2023, 4, 28, 9, 46, 51, 930);
            // 
            // btn_comfirm
            // 
            btn_comfirm.BorderRadius = 10;
            btn_comfirm.CustomizableEdges = customizableEdges25;
            btn_comfirm.DisabledState.BorderColor = Color.DarkGray;
            btn_comfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_comfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_comfirm.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_comfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_comfirm.FillColor = Color.Red;
            btn_comfirm.FillColor2 = Color.Red;
            btn_comfirm.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_comfirm.ForeColor = Color.White;
            btn_comfirm.Location = new Point(233, 438);
            btn_comfirm.Name = "btn_comfirm";
            btn_comfirm.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btn_comfirm.Size = new Size(157, 56);
            btn_comfirm.TabIndex = 8;
            btn_comfirm.Text = "Xác nhận";
            btn_comfirm.Click += btn_comfirm_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(62, 313);
            label6.Name = "label6";
            label6.Size = new Size(92, 28);
            label6.TabIndex = 7;
            label6.Text = "Phân loại";
            // 
            // txb_addType
            // 
            txb_addType.BorderColor = Color.Black;
            txb_addType.BorderRadius = 10;
            txb_addType.CustomizableEdges = customizableEdges27;
            txb_addType.DefaultText = "";
            txb_addType.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addType.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addType.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addType.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addType.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addType.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addType.ForeColor = Color.Black;
            txb_addType.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addType.Location = new Point(62, 347);
            txb_addType.Name = "txb_addType";
            txb_addType.PasswordChar = '\0';
            txb_addType.PlaceholderText = "";
            txb_addType.SelectedText = "";
            txb_addType.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txb_addType.Size = new Size(328, 45);
            txb_addType.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(517, 184);
            label5.Name = "label5";
            label5.Size = new Size(81, 28);
            label5.TabIndex = 5;
            label5.Text = "Đơn giá";
            // 
            // txb_addPrice
            // 
            txb_addPrice.BorderColor = Color.Black;
            txb_addPrice.BorderRadius = 10;
            txb_addPrice.CustomizableEdges = customizableEdges29;
            txb_addPrice.DefaultText = "";
            txb_addPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addPrice.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addPrice.ForeColor = Color.Black;
            txb_addPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addPrice.Location = new Point(517, 215);
            txb_addPrice.Name = "txb_addPrice";
            txb_addPrice.PasswordChar = '\0';
            txb_addPrice.PlaceholderText = "";
            txb_addPrice.SelectedText = "";
            txb_addPrice.ShadowDecoration.CustomizableEdges = customizableEdges30;
            txb_addPrice.Size = new Size(328, 45);
            txb_addPrice.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(517, 49);
            label3.Name = "label3";
            label3.Size = new Size(92, 28);
            label3.TabIndex = 3;
            label3.Text = "Số lượng";
            // 
            // txb_addAmount
            // 
            txb_addAmount.BorderColor = Color.Black;
            txb_addAmount.BorderRadius = 10;
            txb_addAmount.CustomizableEdges = customizableEdges31;
            txb_addAmount.DefaultText = "";
            txb_addAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addAmount.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addAmount.ForeColor = Color.Black;
            txb_addAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addAmount.Location = new Point(517, 83);
            txb_addAmount.Name = "txb_addAmount";
            txb_addAmount.PasswordChar = '\0';
            txb_addAmount.PlaceholderText = "";
            txb_addAmount.SelectedText = "";
            txb_addAmount.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txb_addAmount.Size = new Size(151, 45);
            txb_addAmount.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(62, 49);
            label1.Name = "label1";
            label1.Size = new Size(130, 28);
            label1.TabIndex = 1;
            label1.Text = "Tên sản phẩm";
            // 
            // txb_addNamePro
            // 
            txb_addNamePro.BorderColor = Color.Black;
            txb_addNamePro.BorderRadius = 10;
            txb_addNamePro.CustomizableEdges = customizableEdges33;
            txb_addNamePro.DefaultText = "";
            txb_addNamePro.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addNamePro.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addNamePro.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addNamePro.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addNamePro.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addNamePro.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addNamePro.ForeColor = Color.Black;
            txb_addNamePro.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addNamePro.Location = new Point(62, 83);
            txb_addNamePro.Name = "txb_addNamePro";
            txb_addNamePro.PasswordChar = '\0';
            txb_addNamePro.PlaceholderText = "";
            txb_addNamePro.SelectedText = "";
            txb_addNamePro.ShadowDecoration.CustomizableEdges = customizableEdges34;
            txb_addNamePro.Size = new Size(328, 45);
            txb_addNamePro.TabIndex = 0;
            // 
            // pn_mgmProduct
            // 
            pn_mgmProduct.BorderRadius = 30;
            pn_mgmProduct.BorderThickness = 1;
            pn_mgmProduct.Controls.Add(pt_searchPro);
            pn_mgmProduct.Controls.Add(txb_searchProduct);
            pn_mgmProduct.Controls.Add(btn_addProduct);
            pn_mgmProduct.Controls.Add(panel4);
            pn_mgmProduct.CustomizableEdges = customizableEdges41;
            pn_mgmProduct.Location = new Point(24, 100);
            pn_mgmProduct.Name = "pn_mgmProduct";
            pn_mgmProduct.ShadowDecoration.CustomizableEdges = customizableEdges42;
            pn_mgmProduct.Size = new Size(968, 725);
            pn_mgmProduct.TabIndex = 14;
            pn_mgmProduct.Visible = false;
            // 
            // pt_searchPro
            // 
            pt_searchPro.BackColor = Color.White;
            pt_searchPro.Image = Properties.Resources.search1;
            pt_searchPro.Location = new Point(373, 26);
            pt_searchPro.Name = "pt_searchPro";
            pt_searchPro.Size = new Size(39, 36);
            pt_searchPro.SizeMode = PictureBoxSizeMode.CenterImage;
            pt_searchPro.TabIndex = 5;
            pt_searchPro.TabStop = false;
            pt_searchPro.Click += pt_searchPro_Click;
            // 
            // txb_searchProduct
            // 
            txb_searchProduct.BackColor = Color.White;
            txb_searchProduct.BorderColor = Color.Black;
            txb_searchProduct.BorderRadius = 10;
            txb_searchProduct.CustomizableEdges = customizableEdges37;
            txb_searchProduct.DefaultText = "";
            txb_searchProduct.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_searchProduct.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_searchProduct.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_searchProduct.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_searchProduct.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_searchProduct.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_searchProduct.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_searchProduct.Location = new Point(17, 17);
            txb_searchProduct.Name = "txb_searchProduct";
            txb_searchProduct.PasswordChar = '\0';
            txb_searchProduct.PlaceholderText = "";
            txb_searchProduct.SelectedText = "";
            txb_searchProduct.ShadowDecoration.CustomizableEdges = customizableEdges38;
            txb_searchProduct.Size = new Size(409, 54);
            txb_searchProduct.TabIndex = 4;
            // 
            // btn_addProduct
            // 
            btn_addProduct.BackColor = Color.White;
            btn_addProduct.BorderColor = Color.White;
            btn_addProduct.BorderRadius = 10;
            btn_addProduct.BorderThickness = 1;
            btn_addProduct.CustomizableEdges = customizableEdges39;
            btn_addProduct.DisabledState.BorderColor = Color.DarkGray;
            btn_addProduct.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_addProduct.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_addProduct.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_addProduct.FillColor = Color.FromArgb(248, 9, 9);
            btn_addProduct.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btn_addProduct.ForeColor = Color.White;
            btn_addProduct.Location = new Point(646, 17);
            btn_addProduct.Name = "btn_addProduct";
            btn_addProduct.ShadowDecoration.CustomizableEdges = customizableEdges40;
            btn_addProduct.Size = new Size(225, 56);
            btn_addProduct.TabIndex = 3;
            btn_addProduct.Text = "Thêm sản phẩm";
            btn_addProduct.Click += btn_addProduct_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(dgv_mgmProduct);
            panel4.Location = new Point(17, 79);
            panel4.Name = "panel4";
            panel4.Size = new Size(930, 627);
            panel4.TabIndex = 2;
            // 
            // dgv_mgmProduct
            // 
            dataGridViewCellStyle4.BackColor = Color.White;
            dgv_mgmProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.Red;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgv_mgmProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgv_mgmProduct.ColumnHeadersHeight = 50;
            dgv_mgmProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = Color.White;
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgv_mgmProduct.DefaultCellStyle = dataGridViewCellStyle6;
            dgv_mgmProduct.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.Location = new Point(3, 3);
            dgv_mgmProduct.Name = "dgv_mgmProduct";
            dgv_mgmProduct.RowHeadersVisible = false;
            dgv_mgmProduct.RowHeadersWidth = 51;
            dgv_mgmProduct.RowTemplate.Height = 29;
            dgv_mgmProduct.Size = new Size(918, 621);
            dgv_mgmProduct.TabIndex = 1;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.Height = 50;
            dgv_mgmProduct.ThemeStyle.ReadOnly = false;
            dgv_mgmProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_mgmProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mgmProduct.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_mgmProduct.ThemeStyle.RowsStyle.Height = 29;
            dgv_mgmProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // lb_titilePage
            // 
            lb_titilePage.AutoSize = true;
            lb_titilePage.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lb_titilePage.ForeColor = Color.Black;
            lb_titilePage.Location = new Point(24, 5);
            lb_titilePage.Name = "lb_titilePage";
            lb_titilePage.Size = new Size(294, 81);
            lb_titilePage.TabIndex = 15;
            lb_titilePage.Text = "Trang chủ";
            // 
            // pn_homepage
            // 
            pn_homepage.BorderRadius = 30;
            pn_homepage.Controls.Add(panel3);
            pn_homepage.Controls.Add(pn_total_month);
            pn_homepage.Controls.Add(pn_chart);
            pn_homepage.CustomizableEdges = customizableEdges45;
            pn_homepage.Location = new Point(24, 100);
            pn_homepage.Name = "pn_homepage";
            pn_homepage.ShadowDecoration.CustomizableEdges = customizableEdges46;
            pn_homepage.Size = new Size(968, 725);
            pn_homepage.TabIndex = 13;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(dgv_order);
            panel3.Controls.Add(label4);
            panel3.Location = new Point(0, 362);
            panel3.Name = "panel3";
            panel3.Size = new Size(941, 330);
            panel3.TabIndex = 2;
            // 
            // dgv_order
            // 
            dataGridViewCellStyle7.BackColor = Color.White;
            dgv_order.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = Color.Red;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            dgv_order.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            dgv_order.ColumnHeadersHeight = 50;
            dgv_order.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.White;
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor = Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = Color.White;
            dataGridViewCellStyle9.SelectionForeColor = Color.Black;
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.False;
            dgv_order.DefaultCellStyle = dataGridViewCellStyle9;
            dgv_order.GridColor = Color.FromArgb(231, 229, 255);
            dgv_order.Location = new Point(3, 67);
            dgv_order.Name = "dgv_order";
            dgv_order.RowHeadersVisible = false;
            dgv_order.RowHeadersWidth = 51;
            dgv_order.RowTemplate.Height = 29;
            dgv_order.Size = new Size(935, 263);
            dgv_order.TabIndex = 1;
            dgv_order.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_order.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_order.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_order.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_order.ThemeStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_order.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_order.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_order.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_order.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_order.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_order.ThemeStyle.HeaderStyle.Height = 50;
            dgv_order.ThemeStyle.ReadOnly = false;
            dgv_order.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_order.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_order.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_order.ThemeStyle.RowsStyle.Height = 29;
            dgv_order.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_order.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(17, 16);
            label4.Name = "label4";
            label4.Size = new Size(210, 31);
            label4.TabIndex = 0;
            label4.Text = "Đơn hàng gần đây";
            // 
            // pn_total_month
            // 
            pn_total_month.BackColor = Color.FromArgb(242, 175, 171);
            pn_total_month.BorderColor = Color.FromArgb(242, 175, 171);
            pn_total_month.BorderRadius = 20;
            pn_total_month.BorderThickness = 1;
            pn_total_month.Controls.Add(lb_turnover_month);
            pn_total_month.Controls.Add(label2);
            pn_total_month.CustomizableEdges = customizableEdges43;
            pn_total_month.Location = new Point(589, 26);
            pn_total_month.Name = "pn_total_month";
            pn_total_month.ShadowDecoration.CustomizableEdges = customizableEdges44;
            pn_total_month.Size = new Size(352, 318);
            pn_total_month.TabIndex = 1;
            // 
            // lb_turnover_month
            // 
            lb_turnover_month.AutoSize = true;
            lb_turnover_month.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lb_turnover_month.ForeColor = Color.Black;
            lb_turnover_month.Location = new Point(22, 65);
            lb_turnover_month.Name = "lb_turnover_month";
            lb_turnover_month.Size = new Size(108, 28);
            lb_turnover_month.TabIndex = 1;
            lb_turnover_month.Text = "50,000,000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(22, 23);
            label2.Name = "label2";
            label2.Size = new Size(113, 28);
            label2.TabIndex = 0;
            label2.Text = "Tổng tháng";
            // 
            // pn_chart
            // 
            pn_chart.BackColor = Color.White;
            pn_chart.BorderStyle = BorderStyle.FixedSingle;
            pn_chart.Location = new Point(33, 26);
            pn_chart.Name = "pn_chart";
            pn_chart.Size = new Size(550, 318);
            pn_chart.TabIndex = 0;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2Panel1.AutoRoundedCorners = true;
            guna2Panel1.BackColor = Color.FromArgb(248, 9, 9);
            guna2Panel1.BorderColor = Color.Transparent;
            guna2Panel1.BorderRadius = 39;
            guna2Panel1.BorderThickness = 1;
            guna2Panel1.Controls.Add(lb_nameUser2);
            guna2Panel1.Controls.Add(pictureBox3);
            guna2Panel1.CustomBorderColor = Color.FromArgb(248, 9, 9);
            guna2Panel1.CustomizableEdges = customizableEdges47;
            guna2Panel1.FillColor = Color.White;
            guna2Panel1.Location = new Point(786, 5);
            guna2Panel1.Margin = new Padding(3, 4, 3, 4);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges48;
            guna2Panel1.Size = new Size(206, 80);
            guna2Panel1.TabIndex = 14;
            // 
            // lb_nameUser2
            // 
            lb_nameUser2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lb_nameUser2.AutoSize = true;
            lb_nameUser2.BackColor = Color.White;
            lb_nameUser2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            lb_nameUser2.ForeColor = Color.Black;
            lb_nameUser2.Location = new Point(93, 27);
            lb_nameUser2.Name = "lb_nameUser2";
            lb_nameUser2.Size = new Size(92, 25);
            lb_nameUser2.TabIndex = 1;
            lb_nameUser2.Text = "Hợp Kiên";
            // 
            // pictureBox3
            // 
            pictureBox3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox3.BackColor = Color.White;
            pictureBox3.Image = Properties.Resources.user2;
            pictureBox3.Location = new Point(29, 11);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 61);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1216, 845);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "AdminForm";
            Text = "x";
            Load += AdminForm_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            pn_addProduct.ResumeLayout(false);
            pn_orders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_orders).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptb_addImagePro).EndInit();
            pn_mgmProduct.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pt_searchPro).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_mgmProduct).EndInit();
            pn_homepage.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_order).EndInit();
            pn_total_month.ResumeLayout(false);
            pn_total_month.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel pn_choice;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton ordersPage;
        private Guna.UI2.WinForms.Guna2GradientButton homepage;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton mgmProductPage;
        private Panel panel2;
        private Label lb_titilePage;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_homepage;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label lb_nameUser2;
        private PictureBox pictureBox3;
        private Panel panel3;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_order;
        private Label label4;
        private Guna.UI2.WinForms.Guna2GradientPanel pn_total_month;
        private Label lb_turnover_month;
        private Label label2;
        private Panel pn_chart;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_mgmProduct;
        private PictureBox pt_searchPro;
        private Guna.UI2.WinForms.Guna2TextBox txb_searchProduct;
        private Guna.UI2.WinForms.Guna2Button btn_addProduct;
        private Panel panel4;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_mgmProduct;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_addProduct;
        private Panel panel5;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private Label label7;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_addPro;
        private Guna.UI2.WinForms.Guna2GradientButton btn_comfirm;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txb_addType;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txb_addPrice;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txb_addAmount;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txb_addNamePro;
        private Label label8;
        private Guna.UI2.WinForms.Guna2Button btn_upload;
        private PictureBox ptb_addImagePro;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txb_shipment;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_orders;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_orders;
    }
}