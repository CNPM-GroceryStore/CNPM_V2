﻿namespace GroceryStore
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle16 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle17 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle18 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges55 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges56 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges54 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges59 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges60 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle19 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle20 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle21 = new DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges57 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges58 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges61 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges62 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pn_btn = new Panel();
            btn_mngStaff = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_mngSupplier = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_ordersPage = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_homepage = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_staticpage = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_mgmProductPage = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_mngClient = new Guna.UI2.WinForms.Guna2GradientButton();
            pictureBox1 = new PictureBox();
            pn_page = new Panel();
            pn_mngStaff = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_mngStaff = new Guna.UI2.WinForms.Guna2DataGridView();
            pn_mgmProduct = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_mgmProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            panel2 = new Panel();
            btn_addProduct = new Guna.UI2.WinForms.Guna2Button();
            pt_searchPro = new PictureBox();
            txb_searchProduct = new Guna.UI2.WinForms.Guna2TextBox();
            pn_supplier = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_supplier = new Guna.UI2.WinForms.Guna2DataGridView();
            pn_mngClient = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_mngClient = new Guna.UI2.WinForms.Guna2DataGridView();
            pn_staticPage = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_staticByMonth = new Guna.UI2.WinForms.Guna2DataGridView();
            panel6 = new Panel();
            dtp_choseTime = new Guna.UI2.WinForms.Guna2DateTimePicker();
            btn_printStatic = new Guna.UI2.WinForms.Guna2Button();
            pn_ordersInDate = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            dgv_orders = new Guna.UI2.WinForms.Guna2DataGridView();
            pn_addProduct = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            splitContainer1 = new SplitContainer();
            panel5 = new Panel();
            panel14 = new Panel();
            btn_comfirm = new Guna.UI2.WinForms.Guna2GradientButton();
            btn_cancelAddPro = new Guna.UI2.WinForms.Guna2GradientButton();
            panel10 = new Panel();
            dtp_addPro = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label7 = new Label();
            panel11 = new Panel();
            splitContainer2 = new SplitContainer();
            label6 = new Label();
            cbb_addtype = new Guna.UI2.WinForms.Guna2ComboBox();
            cbb_supplier = new Guna.UI2.WinForms.Guna2ComboBox();
            label10 = new Label();
            panel9 = new Panel();
            label1 = new Label();
            txb_addNamePro = new Guna.UI2.WinForms.Guna2TextBox();
            panel7 = new Panel();
            splitContainer3 = new SplitContainer();
            label3 = new Label();
            txb_addAmount = new Guna.UI2.WinForms.Guna2TextBox();
            label9 = new Label();
            txb_shipment = new Guna.UI2.WinForms.Guna2TextBox();
            panel20 = new Panel();
            splitContainer4 = new SplitContainer();
            btn_upload = new Guna.UI2.WinForms.Guna2Button();
            ptb_addImagePro = new PictureBox();
            label8 = new Label();
            panel19 = new Panel();
            txb_addPrice = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            pn_homepage = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            panel3 = new Panel();
            dgv_order = new Guna.UI2.WinForms.Guna2DataGridView();
            label4 = new Label();
            panel1 = new Panel();
            chart_turnover = new System.Windows.Forms.DataVisualization.Charting.Chart();
            pn_total_month = new Guna.UI2.WinForms.Guna2GradientPanel();
            lb_turnover_month = new Label();
            label2 = new Label();
            panel4 = new Panel();
            lb_titilePage = new Label();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            lb_nameUser2 = new Label();
            pictureBox3 = new PictureBox();
            pn_btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pn_page.SuspendLayout();
            pn_mngStaff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_mngStaff).BeginInit();
            pn_mgmProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_mgmProduct).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pt_searchPro).BeginInit();
            pn_supplier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_supplier).BeginInit();
            pn_mngClient.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_mngClient).BeginInit();
            pn_staticPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_staticByMonth).BeginInit();
            panel6.SuspendLayout();
            pn_ordersInDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_orders).BeginInit();
            pn_addProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            panel5.SuspendLayout();
            panel14.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).BeginInit();
            splitContainer2.Panel1.SuspendLayout();
            splitContainer2.Panel2.SuspendLayout();
            splitContainer2.SuspendLayout();
            panel9.SuspendLayout();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer3).BeginInit();
            splitContainer3.Panel1.SuspendLayout();
            splitContainer3.Panel2.SuspendLayout();
            splitContainer3.SuspendLayout();
            panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer4).BeginInit();
            splitContainer4.Panel1.SuspendLayout();
            splitContainer4.Panel2.SuspendLayout();
            splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptb_addImagePro).BeginInit();
            panel19.SuspendLayout();
            pn_homepage.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_order).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chart_turnover).BeginInit();
            pn_total_month.SuspendLayout();
            panel4.SuspendLayout();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pn_btn
            // 
            pn_btn.BackColor = Color.White;
            pn_btn.Controls.Add(btn_mngStaff);
            pn_btn.Controls.Add(btn_mngSupplier);
            pn_btn.Controls.Add(btn_ordersPage);
            pn_btn.Controls.Add(btn_homepage);
            pn_btn.Controls.Add(btn_staticpage);
            pn_btn.Controls.Add(btn_mgmProductPage);
            pn_btn.Controls.Add(btn_mngClient);
            pn_btn.Controls.Add(pictureBox1);
            pn_btn.Dock = DockStyle.Left;
            pn_btn.Location = new Point(0, 0);
            pn_btn.Margin = new Padding(3, 4, 3, 4);
            pn_btn.Name = "pn_btn";
            pn_btn.Size = new Size(202, 845);
            pn_btn.TabIndex = 6;
            // 
            // btn_mngStaff
            // 
            btn_mngStaff.CustomizableEdges = customizableEdges1;
            btn_mngStaff.DisabledState.BorderColor = Color.DarkGray;
            btn_mngStaff.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_mngStaff.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_mngStaff.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_mngStaff.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_mngStaff.FillColor = Color.White;
            btn_mngStaff.FillColor2 = Color.White;
            btn_mngStaff.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_mngStaff.ForeColor = Color.Black;
            btn_mngStaff.Image = Properties.Resources.manager_customer_employee1;
            btn_mngStaff.ImageAlign = HorizontalAlignment.Left;
            btn_mngStaff.Location = new Point(3, 389);
            btn_mngStaff.Name = "btn_mngStaff";
            btn_mngStaff.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btn_mngStaff.Size = new Size(196, 53);
            btn_mngStaff.TabIndex = 14;
            btn_mngStaff.Text = "Quản lí nhân viên";
            btn_mngStaff.TextAlign = HorizontalAlignment.Left;
            btn_mngStaff.Click += btn_mngStaff_Click;
            // 
            // btn_mngSupplier
            // 
            btn_mngSupplier.CustomizableEdges = customizableEdges3;
            btn_mngSupplier.DisabledState.BorderColor = Color.DarkGray;
            btn_mngSupplier.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_mngSupplier.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_mngSupplier.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_mngSupplier.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_mngSupplier.FillColor = Color.White;
            btn_mngSupplier.FillColor2 = Color.White;
            btn_mngSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_mngSupplier.ForeColor = Color.Black;
            btn_mngSupplier.Image = (Image)resources.GetObject("btn_mngSupplier.Image");
            btn_mngSupplier.ImageAlign = HorizontalAlignment.Left;
            btn_mngSupplier.Location = new Point(3, 507);
            btn_mngSupplier.Name = "btn_mngSupplier";
            btn_mngSupplier.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btn_mngSupplier.Size = new Size(196, 53);
            btn_mngSupplier.TabIndex = 13;
            btn_mngSupplier.Text = "Nhà cung cấp";
            btn_mngSupplier.TextAlign = HorizontalAlignment.Left;
            btn_mngSupplier.Click += btn_mngSupplier_Click;
            // 
            // btn_ordersPage
            // 
            btn_ordersPage.CustomizableEdges = customizableEdges5;
            btn_ordersPage.DisabledState.BorderColor = Color.DarkGray;
            btn_ordersPage.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_ordersPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_ordersPage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_ordersPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_ordersPage.FillColor = Color.White;
            btn_ordersPage.FillColor2 = Color.White;
            btn_ordersPage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_ordersPage.ForeColor = Color.Black;
            btn_ordersPage.Image = (Image)resources.GetObject("btn_ordersPage.Image");
            btn_ordersPage.ImageAlign = HorizontalAlignment.Left;
            btn_ordersPage.Location = new Point(3, 212);
            btn_ordersPage.Name = "btn_ordersPage";
            btn_ordersPage.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btn_ordersPage.Size = new Size(196, 53);
            btn_ordersPage.TabIndex = 12;
            btn_ordersPage.Text = "Đơn hàng hôm nay";
            btn_ordersPage.TextAlign = HorizontalAlignment.Left;
            btn_ordersPage.Click += ordersPage_Click;
            // 
            // btn_homepage
            // 
            btn_homepage.CustomizableEdges = customizableEdges7;
            btn_homepage.DisabledState.BorderColor = Color.DarkGray;
            btn_homepage.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_homepage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_homepage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_homepage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_homepage.FillColor = Color.White;
            btn_homepage.FillColor2 = Color.White;
            btn_homepage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_homepage.ForeColor = Color.Black;
            btn_homepage.Image = (Image)resources.GetObject("btn_homepage.Image");
            btn_homepage.ImageAlign = HorizontalAlignment.Left;
            btn_homepage.Location = new Point(3, 153);
            btn_homepage.Name = "btn_homepage";
            btn_homepage.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btn_homepage.Size = new Size(196, 53);
            btn_homepage.TabIndex = 11;
            btn_homepage.Text = "Trang chủ";
            btn_homepage.TextAlign = HorizontalAlignment.Left;
            btn_homepage.Click += homepage_Click;
            // 
            // btn_staticpage
            // 
            btn_staticpage.CustomizableEdges = customizableEdges9;
            btn_staticpage.DisabledState.BorderColor = Color.DarkGray;
            btn_staticpage.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_staticpage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_staticpage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_staticpage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_staticpage.FillColor = Color.White;
            btn_staticpage.FillColor2 = Color.White;
            btn_staticpage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_staticpage.ForeColor = Color.Black;
            btn_staticpage.Image = (Image)resources.GetObject("btn_staticpage.Image");
            btn_staticpage.ImageAlign = HorizontalAlignment.Left;
            btn_staticpage.Location = new Point(3, 271);
            btn_staticpage.Name = "btn_staticpage";
            btn_staticpage.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btn_staticpage.Size = new Size(196, 53);
            btn_staticpage.TabIndex = 9;
            btn_staticpage.Text = "Thống kê";
            btn_staticpage.TextAlign = HorizontalAlignment.Left;
            btn_staticpage.Click += btn_staticpage_Click;
            // 
            // btn_mgmProductPage
            // 
            btn_mgmProductPage.CustomizableEdges = customizableEdges11;
            btn_mgmProductPage.DisabledState.BorderColor = Color.DarkGray;
            btn_mgmProductPage.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_mgmProductPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_mgmProductPage.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_mgmProductPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_mgmProductPage.FillColor = Color.White;
            btn_mgmProductPage.FillColor2 = Color.White;
            btn_mgmProductPage.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_mgmProductPage.ForeColor = Color.Black;
            btn_mgmProductPage.Image = (Image)resources.GetObject("btn_mgmProductPage.Image");
            btn_mgmProductPage.ImageAlign = HorizontalAlignment.Left;
            btn_mgmProductPage.Location = new Point(3, 330);
            btn_mgmProductPage.Name = "btn_mgmProductPage";
            btn_mgmProductPage.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btn_mgmProductPage.Size = new Size(196, 53);
            btn_mgmProductPage.TabIndex = 8;
            btn_mgmProductPage.Text = "Quản lí sản phẩm";
            btn_mgmProductPage.TextAlign = HorizontalAlignment.Left;
            btn_mgmProductPage.Click += mgmProductPage_Click;
            // 
            // btn_mngClient
            // 
            btn_mngClient.CustomizableEdges = customizableEdges13;
            btn_mngClient.DisabledState.BorderColor = Color.DarkGray;
            btn_mngClient.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_mngClient.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_mngClient.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_mngClient.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_mngClient.FillColor = Color.White;
            btn_mngClient.FillColor2 = Color.White;
            btn_mngClient.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_mngClient.ForeColor = Color.Black;
            btn_mngClient.Image = Properties.Resources.manager_customer_employee;
            btn_mngClient.ImageAlign = HorizontalAlignment.Left;
            btn_mngClient.Location = new Point(3, 448);
            btn_mngClient.Name = "btn_mngClient";
            btn_mngClient.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btn_mngClient.Size = new Size(196, 53);
            btn_mngClient.TabIndex = 6;
            btn_mngClient.Text = "Quản lí khách hàng";
            btn_mngClient.TextAlign = HorizontalAlignment.Left;
            btn_mngClient.Click += btn_mngClient_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logoCricleK3;
            pictureBox1.Location = new Point(28, 4);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(133, 133);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pn_page
            // 
            pn_page.BackColor = Color.FromArgb(248, 9, 9);
            pn_page.Controls.Add(pn_mngStaff);
            pn_page.Controls.Add(pn_mgmProduct);
            pn_page.Controls.Add(pn_supplier);
            pn_page.Controls.Add(pn_mngClient);
            pn_page.Controls.Add(pn_staticPage);
            pn_page.Controls.Add(pn_ordersInDate);
            pn_page.Controls.Add(pn_addProduct);
            pn_page.Controls.Add(pn_homepage);
            pn_page.Controls.Add(panel4);
            pn_page.Dock = DockStyle.Fill;
            pn_page.Location = new Point(202, 0);
            pn_page.Name = "pn_page";
            pn_page.Padding = new Padding(10);
            pn_page.Size = new Size(1014, 845);
            pn_page.TabIndex = 7;
            // 
            // pn_mngStaff
            // 
            pn_mngStaff.BorderRadius = 30;
            pn_mngStaff.BorderThickness = 1;
            pn_mngStaff.Controls.Add(dgv_mngStaff);
            pn_mngStaff.CustomizableEdges = customizableEdges15;
            pn_mngStaff.Dock = DockStyle.Fill;
            pn_mngStaff.Location = new Point(10, 101);
            pn_mngStaff.Name = "pn_mngStaff";
            pn_mngStaff.Padding = new Padding(20);
            pn_mngStaff.ShadowDecoration.CustomizableEdges = customizableEdges16;
            pn_mngStaff.Size = new Size(994, 734);
            pn_mngStaff.TabIndex = 15;
            pn_mngStaff.Visible = false;
            // 
            // dgv_mngStaff
            // 
            dgv_mngStaff.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv_mngStaff.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv_mngStaff.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv_mngStaff.ColumnHeadersHeight = 50;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.White;
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv_mngStaff.DefaultCellStyle = dataGridViewCellStyle3;
            dgv_mngStaff.Dock = DockStyle.Fill;
            dgv_mngStaff.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mngStaff.Location = new Point(20, 20);
            dgv_mngStaff.Margin = new Padding(10);
            dgv_mngStaff.Name = "dgv_mngStaff";
            dgv_mngStaff.RowHeadersVisible = false;
            dgv_mngStaff.RowHeadersWidth = 51;
            dgv_mngStaff.RowTemplate.Height = 29;
            dgv_mngStaff.Size = new Size(954, 694);
            dgv_mngStaff.TabIndex = 1;
            dgv_mngStaff.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_mngStaff.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_mngStaff.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_mngStaff.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_mngStaff.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_mngStaff.ThemeStyle.BackColor = Color.White;
            dgv_mngStaff.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mngStaff.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_mngStaff.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_mngStaff.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mngStaff.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_mngStaff.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_mngStaff.ThemeStyle.HeaderStyle.Height = 50;
            dgv_mngStaff.ThemeStyle.ReadOnly = false;
            dgv_mngStaff.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_mngStaff.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_mngStaff.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mngStaff.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_mngStaff.ThemeStyle.RowsStyle.Height = 29;
            dgv_mngStaff.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_mngStaff.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // pn_mgmProduct
            // 
            pn_mgmProduct.BorderRadius = 30;
            pn_mgmProduct.BorderThickness = 1;
            pn_mgmProduct.Controls.Add(dgv_mgmProduct);
            pn_mgmProduct.Controls.Add(panel2);
            pn_mgmProduct.CustomizableEdges = customizableEdges21;
            pn_mgmProduct.Dock = DockStyle.Fill;
            pn_mgmProduct.Location = new Point(10, 101);
            pn_mgmProduct.Name = "pn_mgmProduct";
            pn_mgmProduct.Padding = new Padding(20);
            pn_mgmProduct.ShadowDecoration.CustomizableEdges = customizableEdges22;
            pn_mgmProduct.Size = new Size(994, 734);
            pn_mgmProduct.TabIndex = 14;
            pn_mgmProduct.Visible = false;
            // 
            // dgv_mgmProduct
            // 
            dgv_mgmProduct.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = Color.White;
            dgv_mgmProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgv_mgmProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgv_mgmProduct.ColumnHeadersHeight = 50;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = Color.White;
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgv_mgmProduct.DefaultCellStyle = dataGridViewCellStyle6;
            dgv_mgmProduct.Dock = DockStyle.Fill;
            dgv_mgmProduct.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.Location = new Point(20, 105);
            dgv_mgmProduct.Margin = new Padding(10);
            dgv_mgmProduct.Name = "dgv_mgmProduct";
            dgv_mgmProduct.RowHeadersVisible = false;
            dgv_mgmProduct.RowHeadersWidth = 51;
            dgv_mgmProduct.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgv_mgmProduct.RowTemplate.Height = 29;
            dgv_mgmProduct.Size = new Size(954, 609);
            dgv_mgmProduct.TabIndex = 1;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_mgmProduct.ThemeStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mgmProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_mgmProduct.ThemeStyle.HeaderStyle.Height = 50;
            dgv_mgmProduct.ThemeStyle.ReadOnly = false;
            dgv_mgmProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_mgmProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_mgmProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mgmProduct.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_mgmProduct.ThemeStyle.RowsStyle.Height = 29;
            dgv_mgmProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_mgmProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgv_mgmProduct.CellContentClick += dgv_mgmProduct_CellContentClick;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(btn_addProduct);
            panel2.Controls.Add(pt_searchPro);
            panel2.Controls.Add(txb_searchProduct);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(20, 20);
            panel2.Margin = new Padding(10);
            panel2.Name = "panel2";
            panel2.Padding = new Padding(10);
            panel2.Size = new Size(954, 85);
            panel2.TabIndex = 6;
            // 
            // btn_addProduct
            // 
            btn_addProduct.BackColor = Color.White;
            btn_addProduct.BorderColor = Color.White;
            btn_addProduct.BorderRadius = 10;
            btn_addProduct.BorderThickness = 1;
            btn_addProduct.CustomizableEdges = customizableEdges17;
            btn_addProduct.DisabledState.BorderColor = Color.DarkGray;
            btn_addProduct.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_addProduct.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_addProduct.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_addProduct.Dock = DockStyle.Right;
            btn_addProduct.FillColor = Color.FromArgb(248, 9, 9);
            btn_addProduct.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btn_addProduct.ForeColor = Color.White;
            btn_addProduct.Location = new Point(719, 10);
            btn_addProduct.Name = "btn_addProduct";
            btn_addProduct.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btn_addProduct.Size = new Size(225, 65);
            btn_addProduct.TabIndex = 3;
            btn_addProduct.Text = "Thêm sản phẩm";
            btn_addProduct.Click += btn_addProduct_Click;
            // 
            // pt_searchPro
            // 
            pt_searchPro.BackColor = Color.White;
            pt_searchPro.Image = Properties.Resources.search1;
            pt_searchPro.Location = new Point(357, 13);
            pt_searchPro.Name = "pt_searchPro";
            pt_searchPro.Size = new Size(53, 59);
            pt_searchPro.SizeMode = PictureBoxSizeMode.CenterImage;
            pt_searchPro.TabIndex = 5;
            pt_searchPro.TabStop = false;
            pt_searchPro.Click += pt_searchPro_Click;
            // 
            // txb_searchProduct
            // 
            txb_searchProduct.BackColor = Color.White;
            txb_searchProduct.BorderColor = Color.Black;
            txb_searchProduct.BorderRadius = 10;
            txb_searchProduct.CustomizableEdges = customizableEdges19;
            txb_searchProduct.DefaultText = "";
            txb_searchProduct.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_searchProduct.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_searchProduct.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_searchProduct.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_searchProduct.Dock = DockStyle.Left;
            txb_searchProduct.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_searchProduct.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_searchProduct.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_searchProduct.Location = new Point(10, 10);
            txb_searchProduct.Name = "txb_searchProduct";
            txb_searchProduct.PasswordChar = '\0';
            txb_searchProduct.PlaceholderText = "";
            txb_searchProduct.SelectedText = "";
            txb_searchProduct.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txb_searchProduct.Size = new Size(409, 65);
            txb_searchProduct.TabIndex = 4;
            // 
            // pn_supplier
            // 
            pn_supplier.BorderRadius = 30;
            pn_supplier.BorderThickness = 1;
            pn_supplier.Controls.Add(dgv_supplier);
            pn_supplier.CustomizableEdges = customizableEdges23;
            pn_supplier.Dock = DockStyle.Fill;
            pn_supplier.Location = new Point(10, 101);
            pn_supplier.Name = "pn_supplier";
            pn_supplier.Padding = new Padding(20);
            pn_supplier.ShadowDecoration.CustomizableEdges = customizableEdges24;
            pn_supplier.Size = new Size(994, 734);
            pn_supplier.TabIndex = 20;
            pn_supplier.Visible = false;
            // 
            // dgv_supplier
            // 
            dgv_supplier.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = Color.White;
            dgv_supplier.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            dgv_supplier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            dgv_supplier.ColumnHeadersHeight = 50;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.White;
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor = Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = Color.White;
            dataGridViewCellStyle9.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.False;
            dgv_supplier.DefaultCellStyle = dataGridViewCellStyle9;
            dgv_supplier.Dock = DockStyle.Fill;
            dgv_supplier.GridColor = Color.FromArgb(231, 229, 255);
            dgv_supplier.Location = new Point(20, 20);
            dgv_supplier.Margin = new Padding(10);
            dgv_supplier.Name = "dgv_supplier";
            dgv_supplier.RowHeadersVisible = false;
            dgv_supplier.RowHeadersWidth = 51;
            dgv_supplier.RowTemplate.Height = 29;
            dgv_supplier.Size = new Size(954, 694);
            dgv_supplier.TabIndex = 2;
            dgv_supplier.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_supplier.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_supplier.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_supplier.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_supplier.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_supplier.ThemeStyle.BackColor = Color.White;
            dgv_supplier.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_supplier.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_supplier.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_supplier.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_supplier.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_supplier.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_supplier.ThemeStyle.HeaderStyle.Height = 50;
            dgv_supplier.ThemeStyle.ReadOnly = false;
            dgv_supplier.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_supplier.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_supplier.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_supplier.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_supplier.ThemeStyle.RowsStyle.Height = 29;
            dgv_supplier.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_supplier.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // pn_mngClient
            // 
            pn_mngClient.BorderRadius = 30;
            pn_mngClient.BorderThickness = 1;
            pn_mngClient.Controls.Add(dgv_mngClient);
            pn_mngClient.CustomizableEdges = customizableEdges25;
            pn_mngClient.Dock = DockStyle.Fill;
            pn_mngClient.Location = new Point(10, 101);
            pn_mngClient.Name = "pn_mngClient";
            pn_mngClient.Padding = new Padding(20);
            pn_mngClient.ShadowDecoration.CustomizableEdges = customizableEdges26;
            pn_mngClient.Size = new Size(994, 734);
            pn_mngClient.TabIndex = 19;
            pn_mngClient.Visible = false;
            // 
            // dgv_mngClient
            // 
            dgv_mngClient.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.BackColor = Color.White;
            dgv_mngClient.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle11.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle11.ForeColor = Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.True;
            dgv_mngClient.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            dgv_mngClient.ColumnHeadersHeight = 50;
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.White;
            dataGridViewCellStyle12.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle12.ForeColor = Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = Color.White;
            dataGridViewCellStyle12.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.False;
            dgv_mngClient.DefaultCellStyle = dataGridViewCellStyle12;
            dgv_mngClient.Dock = DockStyle.Fill;
            dgv_mngClient.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mngClient.Location = new Point(20, 20);
            dgv_mngClient.Margin = new Padding(10);
            dgv_mngClient.Name = "dgv_mngClient";
            dgv_mngClient.RowHeadersVisible = false;
            dgv_mngClient.RowHeadersWidth = 51;
            dgv_mngClient.RowTemplate.Height = 29;
            dgv_mngClient.Size = new Size(954, 694);
            dgv_mngClient.TabIndex = 2;
            dgv_mngClient.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_mngClient.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_mngClient.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_mngClient.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_mngClient.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_mngClient.ThemeStyle.BackColor = Color.White;
            dgv_mngClient.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_mngClient.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_mngClient.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_mngClient.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mngClient.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_mngClient.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_mngClient.ThemeStyle.HeaderStyle.Height = 50;
            dgv_mngClient.ThemeStyle.ReadOnly = false;
            dgv_mngClient.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_mngClient.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_mngClient.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_mngClient.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_mngClient.ThemeStyle.RowsStyle.Height = 29;
            dgv_mngClient.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_mngClient.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // pn_staticPage
            // 
            pn_staticPage.BorderRadius = 30;
            pn_staticPage.BorderThickness = 1;
            pn_staticPage.Controls.Add(dgv_staticByMonth);
            pn_staticPage.Controls.Add(panel6);
            pn_staticPage.CustomizableEdges = customizableEdges31;
            pn_staticPage.Dock = DockStyle.Fill;
            pn_staticPage.ImeMode = ImeMode.NoControl;
            pn_staticPage.Location = new Point(10, 101);
            pn_staticPage.Name = "pn_staticPage";
            pn_staticPage.Padding = new Padding(20);
            pn_staticPage.ShadowDecoration.CustomizableEdges = customizableEdges32;
            pn_staticPage.Size = new Size(994, 734);
            pn_staticPage.TabIndex = 18;
            pn_staticPage.Visible = false;
            // 
            // dgv_staticByMonth
            // 
            dgv_staticByMonth.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = Color.White;
            dgv_staticByMonth.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle14.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle14.ForeColor = Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle14.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.True;
            dgv_staticByMonth.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            dgv_staticByMonth.ColumnHeadersHeight = 50;
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = Color.White;
            dataGridViewCellStyle15.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle15.ForeColor = Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = Color.White;
            dataGridViewCellStyle15.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.False;
            dgv_staticByMonth.DefaultCellStyle = dataGridViewCellStyle15;
            dgv_staticByMonth.Dock = DockStyle.Fill;
            dgv_staticByMonth.GridColor = Color.FromArgb(231, 229, 255);
            dgv_staticByMonth.Location = new Point(20, 95);
            dgv_staticByMonth.Margin = new Padding(20);
            dgv_staticByMonth.Name = "dgv_staticByMonth";
            dgv_staticByMonth.RowHeadersVisible = false;
            dgv_staticByMonth.RowHeadersWidth = 51;
            dgv_staticByMonth.RowTemplate.Height = 29;
            dgv_staticByMonth.Size = new Size(954, 619);
            dgv_staticByMonth.TabIndex = 2;
            dgv_staticByMonth.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_staticByMonth.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_staticByMonth.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_staticByMonth.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_staticByMonth.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_staticByMonth.ThemeStyle.BackColor = Color.White;
            dgv_staticByMonth.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_staticByMonth.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_staticByMonth.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_staticByMonth.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_staticByMonth.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_staticByMonth.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_staticByMonth.ThemeStyle.HeaderStyle.Height = 50;
            dgv_staticByMonth.ThemeStyle.ReadOnly = false;
            dgv_staticByMonth.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_staticByMonth.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_staticByMonth.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_staticByMonth.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_staticByMonth.ThemeStyle.RowsStyle.Height = 29;
            dgv_staticByMonth.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_staticByMonth.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(dtp_choseTime);
            panel6.Controls.Add(btn_printStatic);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(20, 20);
            panel6.Margin = new Padding(20);
            panel6.Name = "panel6";
            panel6.Padding = new Padding(10);
            panel6.Size = new Size(954, 75);
            panel6.TabIndex = 5;
            // 
            // dtp_choseTime
            // 
            dtp_choseTime.BackColor = Color.White;
            dtp_choseTime.BorderRadius = 10;
            dtp_choseTime.Checked = true;
            dtp_choseTime.CustomizableEdges = customizableEdges27;
            dtp_choseTime.Dock = DockStyle.Right;
            dtp_choseTime.FillColor = Color.FromArgb(248, 9, 9);
            dtp_choseTime.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtp_choseTime.ForeColor = Color.White;
            dtp_choseTime.Format = DateTimePickerFormat.Custom;
            dtp_choseTime.Location = new Point(720, 10);
            dtp_choseTime.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtp_choseTime.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtp_choseTime.Name = "dtp_choseTime";
            dtp_choseTime.ShadowDecoration.CustomizableEdges = customizableEdges28;
            dtp_choseTime.Size = new Size(224, 55);
            dtp_choseTime.TabIndex = 4;
            dtp_choseTime.Value = new DateTime(2023, 5, 3, 14, 32, 17, 219);
            // 
            // btn_printStatic
            // 
            btn_printStatic.BackColor = Color.White;
            btn_printStatic.BorderRadius = 10;
            btn_printStatic.CustomizableEdges = customizableEdges29;
            btn_printStatic.DisabledState.BorderColor = Color.DarkGray;
            btn_printStatic.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_printStatic.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_printStatic.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_printStatic.Dock = DockStyle.Left;
            btn_printStatic.FillColor = Color.FromArgb(248, 9, 9);
            btn_printStatic.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btn_printStatic.ForeColor = Color.White;
            btn_printStatic.Location = new Point(10, 10);
            btn_printStatic.Name = "btn_printStatic";
            btn_printStatic.ShadowDecoration.CustomizableEdges = customizableEdges30;
            btn_printStatic.Size = new Size(225, 55);
            btn_printStatic.TabIndex = 3;
            btn_printStatic.Text = "In số liệu thống kê";
            btn_printStatic.Click += btn_printStatic_Click;
            // 
            // pn_ordersInDate
            // 
            pn_ordersInDate.BorderRadius = 30;
            pn_ordersInDate.BorderThickness = 1;
            pn_ordersInDate.Controls.Add(dgv_orders);
            pn_ordersInDate.CustomizableEdges = customizableEdges33;
            pn_ordersInDate.Dock = DockStyle.Fill;
            pn_ordersInDate.Location = new Point(10, 101);
            pn_ordersInDate.Name = "pn_ordersInDate";
            pn_ordersInDate.Padding = new Padding(20);
            pn_ordersInDate.ShadowDecoration.CustomizableEdges = customizableEdges34;
            pn_ordersInDate.Size = new Size(994, 734);
            pn_ordersInDate.TabIndex = 16;
            pn_ordersInDate.Visible = false;
            // 
            // dgv_orders
            // 
            dgv_orders.AllowUserToResizeRows = false;
            dataGridViewCellStyle16.BackColor = Color.White;
            dgv_orders.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle17.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle17.ForeColor = Color.Black;
            dataGridViewCellStyle17.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle17.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = DataGridViewTriState.True;
            dgv_orders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            dgv_orders.ColumnHeadersHeight = 50;
            dataGridViewCellStyle18.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = Color.White;
            dataGridViewCellStyle18.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle18.ForeColor = Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = Color.White;
            dataGridViewCellStyle18.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle18.WrapMode = DataGridViewTriState.False;
            dgv_orders.DefaultCellStyle = dataGridViewCellStyle18;
            dgv_orders.Dock = DockStyle.Fill;
            dgv_orders.GridColor = Color.FromArgb(231, 229, 255);
            dgv_orders.Location = new Point(20, 20);
            dgv_orders.Margin = new Padding(10);
            dgv_orders.Name = "dgv_orders";
            dgv_orders.RowHeadersVisible = false;
            dgv_orders.RowHeadersWidth = 51;
            dgv_orders.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgv_orders.RowTemplate.Height = 29;
            dgv_orders.Size = new Size(954, 694);
            dgv_orders.TabIndex = 2;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_orders.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_orders.ThemeStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_orders.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_orders.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_orders.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_orders.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_orders.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_orders.ThemeStyle.HeaderStyle.Height = 50;
            dgv_orders.ThemeStyle.ReadOnly = false;
            dgv_orders.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_orders.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_orders.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_orders.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_orders.ThemeStyle.RowsStyle.Height = 29;
            dgv_orders.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_orders.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // pn_addProduct
            // 
            pn_addProduct.BorderRadius = 30;
            pn_addProduct.BorderThickness = 1;
            pn_addProduct.Controls.Add(splitContainer1);
            pn_addProduct.CustomizableEdges = customizableEdges55;
            pn_addProduct.Dock = DockStyle.Fill;
            pn_addProduct.Location = new Point(10, 101);
            pn_addProduct.Name = "pn_addProduct";
            pn_addProduct.Padding = new Padding(20);
            pn_addProduct.ShadowDecoration.CustomizableEdges = customizableEdges56;
            pn_addProduct.Size = new Size(994, 734);
            pn_addProduct.TabIndex = 15;
            pn_addProduct.Visible = false;
            // 
            // splitContainer1
            // 
            splitContainer1.BackColor = Color.White;
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(20, 20);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.White;
            splitContainer1.Panel1.Controls.Add(panel5);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackColor = Color.White;
            splitContainer1.Panel2.Controls.Add(panel7);
            splitContainer1.Size = new Size(954, 694);
            splitContainer1.SplitterDistance = 477;
            splitContainer1.TabIndex = 24;
            // 
            // panel5
            // 
            panel5.Controls.Add(panel14);
            panel5.Controls.Add(panel10);
            panel5.Controls.Add(panel11);
            panel5.Controls.Add(panel9);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(477, 694);
            panel5.TabIndex = 22;
            // 
            // panel14
            // 
            panel14.Controls.Add(btn_comfirm);
            panel14.Controls.Add(btn_cancelAddPro);
            panel14.Dock = DockStyle.Top;
            panel14.Location = new Point(0, 388);
            panel14.Name = "panel14";
            panel14.Padding = new Padding(20);
            panel14.Size = new Size(477, 98);
            panel14.TabIndex = 21;
            // 
            // btn_comfirm
            // 
            btn_comfirm.BorderRadius = 10;
            btn_comfirm.CustomizableEdges = customizableEdges35;
            btn_comfirm.DisabledState.BorderColor = Color.DarkGray;
            btn_comfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_comfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_comfirm.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_comfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_comfirm.Dock = DockStyle.Right;
            btn_comfirm.FillColor = Color.Red;
            btn_comfirm.FillColor2 = Color.Red;
            btn_comfirm.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_comfirm.ForeColor = Color.White;
            btn_comfirm.Location = new Point(311, 20);
            btn_comfirm.Name = "btn_comfirm";
            btn_comfirm.ShadowDecoration.CustomizableEdges = customizableEdges36;
            btn_comfirm.Size = new Size(146, 58);
            btn_comfirm.TabIndex = 8;
            btn_comfirm.Text = "Xác nhận";
            btn_comfirm.Click += btn_comfirm_Click;
            // 
            // btn_cancelAddPro
            // 
            btn_cancelAddPro.BorderRadius = 10;
            btn_cancelAddPro.CustomizableEdges = customizableEdges37;
            btn_cancelAddPro.DisabledState.BorderColor = Color.DarkGray;
            btn_cancelAddPro.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_cancelAddPro.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_cancelAddPro.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_cancelAddPro.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_cancelAddPro.Dock = DockStyle.Left;
            btn_cancelAddPro.FillColor = Color.LightGray;
            btn_cancelAddPro.FillColor2 = Color.LightGray;
            btn_cancelAddPro.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_cancelAddPro.ForeColor = Color.Black;
            btn_cancelAddPro.Location = new Point(20, 20);
            btn_cancelAddPro.Name = "btn_cancelAddPro";
            btn_cancelAddPro.ShadowDecoration.CustomizableEdges = customizableEdges38;
            btn_cancelAddPro.Size = new Size(146, 58);
            btn_cancelAddPro.TabIndex = 11;
            btn_cancelAddPro.Text = "Hủy";
            btn_cancelAddPro.Click += btn_cancelAddPro_Click;
            // 
            // panel10
            // 
            panel10.Controls.Add(dtp_addPro);
            panel10.Controls.Add(label7);
            panel10.Dock = DockStyle.Top;
            panel10.Location = new Point(0, 261);
            panel10.Name = "panel10";
            panel10.Padding = new Padding(20);
            panel10.Size = new Size(477, 127);
            panel10.TabIndex = 21;
            // 
            // dtp_addPro
            // 
            dtp_addPro.BorderRadius = 10;
            dtp_addPro.Checked = true;
            dtp_addPro.CustomizableEdges = customizableEdges39;
            dtp_addPro.Dock = DockStyle.Bottom;
            dtp_addPro.FillColor = Color.White;
            dtp_addPro.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dtp_addPro.Format = DateTimePickerFormat.Short;
            dtp_addPro.Location = new Point(20, 62);
            dtp_addPro.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtp_addPro.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtp_addPro.Name = "dtp_addPro";
            dtp_addPro.ShadowDecoration.CustomizableEdges = customizableEdges40;
            dtp_addPro.Size = new Size(437, 45);
            dtp_addPro.TabIndex = 9;
            dtp_addPro.Value = new DateTime(2023, 4, 28, 9, 46, 51, 930);
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = DockStyle.Top;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(20, 20);
            label7.Name = "label7";
            label7.Size = new Size(123, 28);
            label7.TabIndex = 10;
            label7.Text = "Hạn sử dụng";
            // 
            // panel11
            // 
            panel11.Controls.Add(splitContainer2);
            panel11.Dock = DockStyle.Top;
            panel11.Location = new Point(0, 136);
            panel11.Name = "panel11";
            panel11.Size = new Size(477, 125);
            panel11.TabIndex = 21;
            // 
            // splitContainer2
            // 
            splitContainer2.Dock = DockStyle.Fill;
            splitContainer2.Location = new Point(0, 0);
            splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            splitContainer2.Panel1.Controls.Add(label6);
            splitContainer2.Panel1.Controls.Add(cbb_addtype);
            splitContainer2.Panel1.Padding = new Padding(20);
            // 
            // splitContainer2.Panel2
            // 
            splitContainer2.Panel2.Controls.Add(cbb_supplier);
            splitContainer2.Panel2.Controls.Add(label10);
            splitContainer2.Panel2.Padding = new Padding(20);
            splitContainer2.Size = new Size(477, 125);
            splitContainer2.SplitterDistance = 232;
            splitContainer2.TabIndex = 0;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Top;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(20, 20);
            label6.Name = "label6";
            label6.Size = new Size(92, 28);
            label6.TabIndex = 7;
            label6.Text = "Phân loại";
            // 
            // cbb_addtype
            // 
            cbb_addtype.BackColor = Color.Transparent;
            cbb_addtype.BorderRadius = 10;
            cbb_addtype.CustomizableEdges = customizableEdges41;
            cbb_addtype.Dock = DockStyle.Bottom;
            cbb_addtype.DrawMode = DrawMode.OwnerDrawFixed;
            cbb_addtype.DropDownStyle = ComboBoxStyle.DropDownList;
            cbb_addtype.FocusedColor = Color.FromArgb(94, 148, 255);
            cbb_addtype.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbb_addtype.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbb_addtype.ForeColor = Color.Black;
            cbb_addtype.ItemHeight = 30;
            cbb_addtype.Items.AddRange(new object[] { "DA", "DU", "DAV", "DGD" });
            cbb_addtype.Location = new Point(20, 69);
            cbb_addtype.Name = "cbb_addtype";
            cbb_addtype.ShadowDecoration.CustomizableEdges = customizableEdges42;
            cbb_addtype.Size = new Size(192, 36);
            cbb_addtype.TabIndex = 18;
            // 
            // cbb_supplier
            // 
            cbb_supplier.BackColor = Color.Transparent;
            cbb_supplier.BorderRadius = 10;
            cbb_supplier.CustomizableEdges = customizableEdges43;
            cbb_supplier.Dock = DockStyle.Bottom;
            cbb_supplier.DrawMode = DrawMode.OwnerDrawFixed;
            cbb_supplier.DropDownStyle = ComboBoxStyle.DropDownList;
            cbb_supplier.FocusedColor = Color.FromArgb(94, 148, 255);
            cbb_supplier.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbb_supplier.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbb_supplier.ForeColor = Color.FromArgb(68, 88, 112);
            cbb_supplier.ItemHeight = 30;
            cbb_supplier.Items.AddRange(new object[] { "Cocacola", "Oishi", "Pepsi", "NumberOne", "Circle K" });
            cbb_supplier.Location = new Point(20, 69);
            cbb_supplier.Name = "cbb_supplier";
            cbb_supplier.ShadowDecoration.CustomizableEdges = customizableEdges44;
            cbb_supplier.Size = new Size(201, 36);
            cbb_supplier.TabIndex = 19;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Dock = DockStyle.Top;
            label10.Location = new Point(20, 20);
            label10.Name = "label10";
            label10.Size = new Size(100, 20);
            label10.TabIndex = 20;
            label10.Text = "Nhà cung cấp";
            // 
            // panel9
            // 
            panel9.Controls.Add(label1);
            panel9.Controls.Add(txb_addNamePro);
            panel9.Dock = DockStyle.Top;
            panel9.Location = new Point(0, 0);
            panel9.Name = "panel9";
            panel9.Padding = new Padding(20);
            panel9.Size = new Size(477, 136);
            panel9.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(20, 20);
            label1.Name = "label1";
            label1.Size = new Size(130, 28);
            label1.TabIndex = 1;
            label1.Text = "Tên sản phẩm";
            // 
            // txb_addNamePro
            // 
            txb_addNamePro.BorderColor = Color.Black;
            txb_addNamePro.BorderRadius = 10;
            txb_addNamePro.CustomizableEdges = customizableEdges45;
            txb_addNamePro.DefaultText = "";
            txb_addNamePro.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addNamePro.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addNamePro.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addNamePro.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addNamePro.Dock = DockStyle.Bottom;
            txb_addNamePro.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addNamePro.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addNamePro.ForeColor = Color.Black;
            txb_addNamePro.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addNamePro.Location = new Point(20, 71);
            txb_addNamePro.Name = "txb_addNamePro";
            txb_addNamePro.Padding = new Padding(5);
            txb_addNamePro.PasswordChar = '\0';
            txb_addNamePro.PlaceholderText = "";
            txb_addNamePro.SelectedText = "";
            txb_addNamePro.ShadowDecoration.CustomizableEdges = customizableEdges46;
            txb_addNamePro.Size = new Size(437, 45);
            txb_addNamePro.TabIndex = 0;
            // 
            // panel7
            // 
            panel7.Controls.Add(splitContainer3);
            panel7.Controls.Add(panel20);
            panel7.Controls.Add(panel19);
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(473, 486);
            panel7.TabIndex = 23;
            // 
            // splitContainer3
            // 
            splitContainer3.Dock = DockStyle.Top;
            splitContainer3.Location = new Point(0, 136);
            splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            splitContainer3.Panel1.Controls.Add(label3);
            splitContainer3.Panel1.Controls.Add(txb_addAmount);
            splitContainer3.Panel1.Padding = new Padding(20);
            // 
            // splitContainer3.Panel2
            // 
            splitContainer3.Panel2.Controls.Add(label9);
            splitContainer3.Panel2.Controls.Add(txb_shipment);
            splitContainer3.Panel2.Padding = new Padding(20);
            splitContainer3.Size = new Size(473, 125);
            splitContainer3.SplitterDistance = 242;
            splitContainer3.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Top;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(20, 20);
            label3.Name = "label3";
            label3.Size = new Size(92, 28);
            label3.TabIndex = 3;
            label3.Text = "Số lượng";
            // 
            // txb_addAmount
            // 
            txb_addAmount.BorderColor = Color.Black;
            txb_addAmount.BorderRadius = 10;
            txb_addAmount.CustomizableEdges = customizableEdges47;
            txb_addAmount.DefaultText = "";
            txb_addAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addAmount.Dock = DockStyle.Bottom;
            txb_addAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addAmount.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addAmount.ForeColor = Color.Black;
            txb_addAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addAmount.Location = new Point(20, 60);
            txb_addAmount.Name = "txb_addAmount";
            txb_addAmount.PasswordChar = '\0';
            txb_addAmount.PlaceholderText = "";
            txb_addAmount.SelectedText = "";
            txb_addAmount.ShadowDecoration.CustomizableEdges = customizableEdges48;
            txb_addAmount.Size = new Size(202, 45);
            txb_addAmount.TabIndex = 2;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = DockStyle.Top;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(20, 20);
            label9.Name = "label9";
            label9.Size = new Size(82, 28);
            label9.TabIndex = 17;
            label9.Text = "Lô hàng";
            // 
            // txb_shipment
            // 
            txb_shipment.BorderColor = Color.Black;
            txb_shipment.BorderRadius = 10;
            txb_shipment.CustomizableEdges = customizableEdges49;
            txb_shipment.DefaultText = "";
            txb_shipment.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_shipment.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_shipment.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_shipment.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_shipment.Dock = DockStyle.Bottom;
            txb_shipment.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_shipment.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_shipment.ForeColor = Color.Black;
            txb_shipment.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_shipment.Location = new Point(20, 60);
            txb_shipment.Name = "txb_shipment";
            txb_shipment.PasswordChar = '\0';
            txb_shipment.PlaceholderText = "";
            txb_shipment.SelectedText = "";
            txb_shipment.ShadowDecoration.CustomizableEdges = customizableEdges50;
            txb_shipment.Size = new Size(187, 45);
            txb_shipment.TabIndex = 16;
            // 
            // panel20
            // 
            panel20.Controls.Add(splitContainer4);
            panel20.Controls.Add(label8);
            panel20.Dock = DockStyle.Bottom;
            panel20.Location = new Point(0, 258);
            panel20.Name = "panel20";
            panel20.Padding = new Padding(20);
            panel20.Size = new Size(473, 228);
            panel20.TabIndex = 23;
            // 
            // splitContainer4
            // 
            splitContainer4.Dock = DockStyle.Bottom;
            splitContainer4.Location = new Point(20, 83);
            splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            splitContainer4.Panel1.Controls.Add(btn_upload);
            // 
            // splitContainer4.Panel2
            // 
            splitContainer4.Panel2.Controls.Add(ptb_addImagePro);
            splitContainer4.Size = new Size(433, 125);
            splitContainer4.SplitterDistance = 144;
            splitContainer4.TabIndex = 14;
            // 
            // btn_upload
            // 
            btn_upload.BorderRadius = 10;
            btn_upload.CustomizableEdges = customizableEdges51;
            btn_upload.DisabledState.BorderColor = Color.DarkGray;
            btn_upload.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_upload.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_upload.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_upload.Dock = DockStyle.Top;
            btn_upload.FillColor = Color.FromArgb(254, 72, 72);
            btn_upload.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_upload.ForeColor = Color.White;
            btn_upload.Location = new Point(0, 0);
            btn_upload.Name = "btn_upload";
            btn_upload.ShadowDecoration.CustomizableEdges = customizableEdges52;
            btn_upload.Size = new Size(144, 53);
            btn_upload.TabIndex = 14;
            btn_upload.Text = "Upload Image";
            btn_upload.Click += upload_Click;
            // 
            // ptb_addImagePro
            // 
            ptb_addImagePro.Dock = DockStyle.Fill;
            ptb_addImagePro.Location = new Point(0, 0);
            ptb_addImagePro.Name = "ptb_addImagePro";
            ptb_addImagePro.Size = new Size(285, 125);
            ptb_addImagePro.SizeMode = PictureBoxSizeMode.Zoom;
            ptb_addImagePro.TabIndex = 15;
            ptb_addImagePro.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = DockStyle.Top;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(20, 20);
            label8.Name = "label8";
            label8.Size = new Size(90, 28);
            label8.TabIndex = 13;
            label8.Text = "Hình ảnh";
            // 
            // panel19
            // 
            panel19.Controls.Add(txb_addPrice);
            panel19.Controls.Add(label5);
            panel19.Dock = DockStyle.Top;
            panel19.Location = new Point(0, 0);
            panel19.Name = "panel19";
            panel19.Padding = new Padding(20);
            panel19.Size = new Size(473, 136);
            panel19.TabIndex = 22;
            // 
            // txb_addPrice
            // 
            txb_addPrice.BorderColor = Color.Black;
            txb_addPrice.BorderRadius = 10;
            txb_addPrice.CustomizableEdges = customizableEdges53;
            txb_addPrice.DefaultText = "";
            txb_addPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txb_addPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txb_addPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txb_addPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txb_addPrice.Dock = DockStyle.Bottom;
            txb_addPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addPrice.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txb_addPrice.ForeColor = Color.Black;
            txb_addPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txb_addPrice.Location = new Point(20, 71);
            txb_addPrice.Name = "txb_addPrice";
            txb_addPrice.PasswordChar = '\0';
            txb_addPrice.PlaceholderText = "";
            txb_addPrice.SelectedText = "";
            txb_addPrice.ShadowDecoration.CustomizableEdges = customizableEdges54;
            txb_addPrice.Size = new Size(433, 45);
            txb_addPrice.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Top;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(20, 20);
            label5.Name = "label5";
            label5.Size = new Size(81, 28);
            label5.TabIndex = 5;
            label5.Text = "Đơn giá";
            // 
            // pn_homepage
            // 
            pn_homepage.BorderRadius = 30;
            pn_homepage.Controls.Add(panel3);
            pn_homepage.Controls.Add(panel1);
            pn_homepage.CustomizableEdges = customizableEdges59;
            pn_homepage.Dock = DockStyle.Fill;
            pn_homepage.Location = new Point(10, 101);
            pn_homepage.Name = "pn_homepage";
            pn_homepage.Padding = new Padding(20);
            pn_homepage.ShadowDecoration.CustomizableEdges = customizableEdges60;
            pn_homepage.Size = new Size(994, 734);
            pn_homepage.TabIndex = 13;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(dgv_order);
            panel3.Controls.Add(label4);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(20, 401);
            panel3.Name = "panel3";
            panel3.Size = new Size(954, 313);
            panel3.TabIndex = 2;
            // 
            // dgv_order
            // 
            dgv_order.AllowUserToResizeRows = false;
            dataGridViewCellStyle19.BackColor = Color.White;
            dgv_order.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            dataGridViewCellStyle20.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle20.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle20.ForeColor = Color.Black;
            dataGridViewCellStyle20.SelectionBackColor = Color.FromArgb(238, 236, 236);
            dataGridViewCellStyle20.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = DataGridViewTriState.True;
            dgv_order.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            dgv_order.ColumnHeadersHeight = 50;
            dataGridViewCellStyle21.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = Color.White;
            dataGridViewCellStyle21.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle21.ForeColor = Color.Black;
            dataGridViewCellStyle21.SelectionBackColor = Color.White;
            dataGridViewCellStyle21.SelectionForeColor = Color.Black;
            dataGridViewCellStyle21.WrapMode = DataGridViewTriState.False;
            dgv_order.DefaultCellStyle = dataGridViewCellStyle21;
            dgv_order.Dock = DockStyle.Bottom;
            dgv_order.GridColor = Color.FromArgb(231, 229, 255);
            dgv_order.Location = new Point(0, 50);
            dgv_order.Margin = new Padding(10);
            dgv_order.Name = "dgv_order";
            dgv_order.RowHeadersVisible = false;
            dgv_order.RowHeadersWidth = 51;
            dgv_order.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgv_order.RowTemplate.Height = 29;
            dgv_order.Size = new Size(954, 263);
            dgv_order.TabIndex = 1;
            dgv_order.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv_order.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv_order.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv_order.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv_order.ThemeStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv_order.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv_order.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv_order.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_order.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv_order.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv_order.ThemeStyle.HeaderStyle.Height = 50;
            dgv_order.ThemeStyle.ReadOnly = false;
            dgv_order.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv_order.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv_order.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgv_order.ThemeStyle.RowsStyle.ForeColor = Color.Transparent;
            dgv_order.ThemeStyle.RowsStyle.Height = 29;
            dgv_order.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv_order.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(17, 16);
            label4.Name = "label4";
            label4.Size = new Size(210, 31);
            label4.TabIndex = 0;
            label4.Text = "Đơn hàng gần đây";
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(chart_turnover);
            panel1.Controls.Add(pn_total_month);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(20, 20);
            panel1.Name = "panel1";
            panel1.Size = new Size(954, 366);
            panel1.TabIndex = 3;
            // 
            // chart_turnover
            // 
            chartArea1.Name = "ChartArea1";
            chart_turnover.ChartAreas.Add(chartArea1);
            chart_turnover.Dock = DockStyle.Fill;
            legend1.Name = "Legend1";
            chart_turnover.Legends.Add(legend1);
            chart_turnover.Location = new Point(0, 0);
            chart_turnover.Name = "chart_turnover";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Doanh thu";
            chart_turnover.Series.Add(series1);
            chart_turnover.Size = new Size(749, 366);
            chart_turnover.TabIndex = 0;
            chart_turnover.Text = "Doanh thu trong năm 2023";
            // 
            // pn_total_month
            // 
            pn_total_month.BackColor = Color.FromArgb(242, 175, 171);
            pn_total_month.BorderColor = Color.FromArgb(242, 175, 171);
            pn_total_month.BorderRadius = 20;
            pn_total_month.BorderThickness = 1;
            pn_total_month.Controls.Add(lb_turnover_month);
            pn_total_month.Controls.Add(label2);
            pn_total_month.CustomizableEdges = customizableEdges57;
            pn_total_month.Dock = DockStyle.Right;
            pn_total_month.Location = new Point(749, 0);
            pn_total_month.Name = "pn_total_month";
            pn_total_month.ShadowDecoration.CustomizableEdges = customizableEdges58;
            pn_total_month.Size = new Size(205, 366);
            pn_total_month.TabIndex = 1;
            // 
            // lb_turnover_month
            // 
            lb_turnover_month.AutoSize = true;
            lb_turnover_month.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lb_turnover_month.ForeColor = Color.Black;
            lb_turnover_month.Location = new Point(22, 65);
            lb_turnover_month.Name = "lb_turnover_month";
            lb_turnover_month.Size = new Size(108, 28);
            lb_turnover_month.TabIndex = 1;
            lb_turnover_month.Text = "50,000,000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(22, 23);
            label2.Name = "label2";
            label2.Size = new Size(113, 28);
            label2.TabIndex = 0;
            label2.Text = "Tổng tháng";
            // 
            // panel4
            // 
            panel4.Controls.Add(lb_titilePage);
            panel4.Controls.Add(guna2Panel1);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(10, 10);
            panel4.Name = "panel4";
            panel4.Padding = new Padding(10);
            panel4.Size = new Size(994, 91);
            panel4.TabIndex = 21;
            // 
            // lb_titilePage
            // 
            lb_titilePage.AutoSize = true;
            lb_titilePage.Dock = DockStyle.Left;
            lb_titilePage.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            lb_titilePage.ForeColor = Color.Black;
            lb_titilePage.Location = new Point(10, 10);
            lb_titilePage.Name = "lb_titilePage";
            lb_titilePage.Size = new Size(294, 81);
            lb_titilePage.TabIndex = 15;
            lb_titilePage.Text = "Trang chủ";
            // 
            // guna2Panel1
            // 
            guna2Panel1.AutoRoundedCorners = true;
            guna2Panel1.BackColor = Color.FromArgb(248, 9, 9);
            guna2Panel1.BorderColor = Color.Transparent;
            guna2Panel1.BorderRadius = 34;
            guna2Panel1.BorderThickness = 1;
            guna2Panel1.Controls.Add(lb_nameUser2);
            guna2Panel1.Controls.Add(pictureBox3);
            guna2Panel1.CustomBorderColor = Color.FromArgb(248, 9, 9);
            guna2Panel1.CustomizableEdges = customizableEdges61;
            guna2Panel1.Dock = DockStyle.Right;
            guna2Panel1.FillColor = Color.White;
            guna2Panel1.Location = new Point(778, 10);
            guna2Panel1.Margin = new Padding(3, 4, 3, 4);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges62;
            guna2Panel1.Size = new Size(206, 71);
            guna2Panel1.TabIndex = 14;
            // 
            // lb_nameUser2
            // 
            lb_nameUser2.AutoSize = true;
            lb_nameUser2.BackColor = Color.White;
            lb_nameUser2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            lb_nameUser2.ForeColor = Color.Black;
            lb_nameUser2.Location = new Point(94, 27);
            lb_nameUser2.Name = "lb_nameUser2";
            lb_nameUser2.Size = new Size(69, 25);
            lb_nameUser2.TabIndex = 1;
            lb_nameUser2.Text = "Admin";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.Image = Properties.Resources.user2;
            pictureBox3.Location = new Point(23, 6);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 61);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1216, 845);
            Controls.Add(pn_page);
            Controls.Add(pn_btn);
            Name = "AdminForm";
            Text = "Admin Form";
            Load += AdminForm_Load;
            pn_btn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pn_page.ResumeLayout(false);
            pn_mngStaff.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_mngStaff).EndInit();
            pn_mgmProduct.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_mgmProduct).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pt_searchPro).EndInit();
            pn_supplier.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_supplier).EndInit();
            pn_mngClient.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_mngClient).EndInit();
            pn_staticPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_staticByMonth).EndInit();
            panel6.ResumeLayout(false);
            pn_ordersInDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_orders).EndInit();
            pn_addProduct.ResumeLayout(false);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            splitContainer2.Panel1.ResumeLayout(false);
            splitContainer2.Panel1.PerformLayout();
            splitContainer2.Panel2.ResumeLayout(false);
            splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).EndInit();
            splitContainer2.ResumeLayout(false);
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel7.ResumeLayout(false);
            splitContainer3.Panel1.ResumeLayout(false);
            splitContainer3.Panel1.PerformLayout();
            splitContainer3.Panel2.ResumeLayout(false);
            splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer3).EndInit();
            splitContainer3.ResumeLayout(false);
            panel20.ResumeLayout(false);
            panel20.PerformLayout();
            splitContainer4.Panel1.ResumeLayout(false);
            splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer4).EndInit();
            splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptb_addImagePro).EndInit();
            panel19.ResumeLayout(false);
            panel19.PerformLayout();
            pn_homepage.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_order).EndInit();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)chart_turnover).EndInit();
            pn_total_month.ResumeLayout(false);
            pn_total_month.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pn_btn;
        private Panel pn_choice;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2GradientButton btn_mngClient;
        private Guna.UI2.WinForms.Guna2GradientButton btn_mngSupplier;
        private Guna.UI2.WinForms.Guna2GradientButton btn_ordersPage;
        private Guna.UI2.WinForms.Guna2GradientButton btn_homepage;
        private Guna.UI2.WinForms.Guna2GradientButton btn_staticpage;
        private Guna.UI2.WinForms.Guna2GradientButton btn_mgmProductPage;
        private Panel pn_page;
        private Label lb_titilePage;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_homepage;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label lb_nameUser2;
        private PictureBox pictureBox3;
        private Panel panel3;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_order;
        private Label label4;
        private Guna.UI2.WinForms.Guna2GradientPanel pn_total_month;
        private Label lb_turnover_month;
        private Label label2;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_mgmProduct;
        private PictureBox pt_searchPro;
        private Guna.UI2.WinForms.Guna2TextBox txb_searchProduct;
        private Guna.UI2.WinForms.Guna2Button btn_addProduct;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_addProduct;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txb_addPrice;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txb_addAmount;
        private Label label8;
        private Guna.UI2.WinForms.Guna2Button btn_upload;
        private PictureBox ptb_addImagePro;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txb_shipment;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_ordersInDate;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_orders;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_turnover;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_staticPage;
        private Guna.UI2.WinForms.Guna2Button btn_printStatic;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_staticByMonth;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_choseTime;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_mngClient;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_mngClient;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_supplier;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_supplier;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_mgmProduct;
        private Panel panel2;
        private Panel panel1;
        private Panel panel4;
        private Panel panel6;
        private Guna.UI2.WinForms.Guna2GradientButton btn_mngStaff;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel pn_mngStaff;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_mngStaff;
        private Panel panel20;
        private Panel panel19;
        private SplitContainer splitContainer1;
        private Label label6;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_addtype;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_supplier;
        private Label label10;
        private Panel panel14;
        private Guna.UI2.WinForms.Guna2GradientButton btn_comfirm;
        private Guna.UI2.WinForms.Guna2GradientButton btn_cancelAddPro;
        private Panel panel9;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txb_addNamePro;
        private Panel panel10;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_addPro;
        private Label label7;
        private Panel panel5;
        private Panel panel11;
        private SplitContainer splitContainer2;
        private Panel panel7;
        private SplitContainer splitContainer3;
        private SplitContainer splitContainer4;
    }
}