﻿namespace GroceryStore
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            btn_home = new Guna.UI2.WinForms.Guna2GradientTileButton();
            btn_drinks = new Guna.UI2.WinForms.Guna2GradientTileButton();
            btn_fast_foods = new Guna.UI2.WinForms.Guna2GradientTileButton();
            btn_others = new Guna.UI2.WinForms.Guna2GradientTileButton();
            panel1 = new Panel();
            btn_maCuaToi = new Guna.UI2.WinForms.Guna2Button();
            btn_tatCa = new Guna.UI2.WinForms.Guna2Button();
            btn_voucher = new Guna.UI2.WinForms.Guna2GradientTileButton();
            pn_choice = new Panel();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            lb_nameUser2 = new Label();
            pictureBox3 = new PictureBox();
            btn_search = new PictureBox();
            tb_search = new TextBox();
            lb_nameUser1 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            lbl_username = new MetroSet_UI.Controls.MetroSetLabel();
            DiemTichLuy = new DiemTichLuy();
            lb_phoBien = new Label();
            lb_danhMucPhu = new Label();
            pb_muiTen = new PictureBox();
            lb_tatCa = new Label();
            lb_chonDanhMuc = new Label();
            flowLayout = new FlowLayoutPanel();
            flowpanel_order_history = new FlowLayoutPanel();
            panel3 = new Panel();
            flowLayoutItemOder = new FlowLayoutPanel();
            ThanhToan = new ThanhToan();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            pictureBox9 = new PictureBox();
            lb_paydate = new Label();
            label6 = new Label();
            cbb_payment = new Guna.UI2.WinForms.Guna2ComboBox();
            panel4 = new Panel();
            lb_history = new Label();
            pictureBox8 = new PictureBox();
            lb_oder = new Label();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btn_search).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb_muiTen).BeginInit();
            panel3.SuspendLayout();
            guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logoCricleK2;
            pictureBox1.Location = new Point(6, 0);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 133);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btn_home
            // 
            btn_home.BorderRadius = 5;
            btn_home.CustomizableEdges = customizableEdges1;
            btn_home.DisabledState.BorderColor = Color.DarkGray;
            btn_home.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_home.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_home.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_home.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_home.FillColor = Color.White;
            btn_home.FillColor2 = Color.White;
            btn_home.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_home.ForeColor = Color.Black;
            btn_home.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            btn_home.HoverState.BorderColor = Color.FromArgb(248, 9, 9);
            btn_home.HoverState.FillColor = Color.FromArgb(248, 9, 9);
            btn_home.HoverState.FillColor2 = Color.FromArgb(248, 9, 9);
            btn_home.Image = Properties.Resources.home;
            btn_home.ImageSize = new Size(36, 35);
            btn_home.Location = new Point(9, 192);
            btn_home.Margin = new Padding(3, 4, 3, 4);
            btn_home.Name = "btn_home";
            btn_home.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btn_home.Size = new Size(111, 111);
            btn_home.TabIndex = 1;
            btn_home.Text = "Trang chủ ";
            btn_home.Click += btn_home_Click;
            // 
            // btn_drinks
            // 
            btn_drinks.BorderRadius = 5;
            btn_drinks.CustomizableEdges = customizableEdges3;
            btn_drinks.DisabledState.BorderColor = Color.DarkGray;
            btn_drinks.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_drinks.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_drinks.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_drinks.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_drinks.FillColor = Color.White;
            btn_drinks.FillColor2 = Color.White;
            btn_drinks.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_drinks.ForeColor = Color.Black;
            btn_drinks.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            btn_drinks.HoverState.BorderColor = Color.FromArgb(248, 9, 9);
            btn_drinks.HoverState.FillColor = Color.FromArgb(248, 9, 9);
            btn_drinks.HoverState.FillColor2 = Color.FromArgb(248, 9, 9);
            btn_drinks.Image = Properties.Resources.drink;
            btn_drinks.ImageSize = new Size(36, 35);
            btn_drinks.Location = new Point(9, 311);
            btn_drinks.Margin = new Padding(3, 4, 3, 4);
            btn_drinks.Name = "btn_drinks";
            btn_drinks.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btn_drinks.Size = new Size(111, 111);
            btn_drinks.TabIndex = 2;
            btn_drinks.Text = "Đồ uống";
            btn_drinks.Click += btn_drinks_Click;
            // 
            // btn_fast_foods
            // 
            btn_fast_foods.BorderRadius = 5;
            btn_fast_foods.CustomizableEdges = customizableEdges5;
            btn_fast_foods.DisabledState.BorderColor = Color.DarkGray;
            btn_fast_foods.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_fast_foods.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_fast_foods.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_fast_foods.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_fast_foods.FillColor = Color.White;
            btn_fast_foods.FillColor2 = Color.White;
            btn_fast_foods.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_fast_foods.ForeColor = Color.Black;
            btn_fast_foods.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            btn_fast_foods.HoverState.BorderColor = Color.FromArgb(248, 9, 9);
            btn_fast_foods.HoverState.FillColor = Color.FromArgb(248, 9, 9);
            btn_fast_foods.HoverState.FillColor2 = Color.FromArgb(248, 9, 9);
            btn_fast_foods.Image = Properties.Resources.snack;
            btn_fast_foods.ImageSize = new Size(36, 35);
            btn_fast_foods.Location = new Point(9, 429);
            btn_fast_foods.Margin = new Padding(3, 4, 3, 4);
            btn_fast_foods.Name = "btn_fast_foods";
            btn_fast_foods.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btn_fast_foods.Size = new Size(111, 111);
            btn_fast_foods.TabIndex = 3;
            btn_fast_foods.Text = "Đồ ăn vặt";
            btn_fast_foods.Click += btn_fast_foods_Click;
            // 
            // btn_others
            // 
            btn_others.BorderRadius = 5;
            btn_others.CustomizableEdges = customizableEdges7;
            btn_others.DisabledState.BorderColor = Color.DarkGray;
            btn_others.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_others.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_others.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_others.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_others.FillColor = Color.White;
            btn_others.FillColor2 = Color.White;
            btn_others.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_others.ForeColor = Color.Black;
            btn_others.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            btn_others.HoverState.BorderColor = Color.FromArgb(248, 9, 9);
            btn_others.HoverState.FillColor = Color.FromArgb(248, 9, 9);
            btn_others.HoverState.FillColor2 = Color.FromArgb(248, 9, 9);
            btn_others.Image = Properties.Resources.food_other;
            btn_others.ImageSize = new Size(36, 35);
            btn_others.Location = new Point(9, 548);
            btn_others.Margin = new Padding(3, 4, 3, 4);
            btn_others.Name = "btn_others";
            btn_others.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btn_others.Size = new Size(111, 111);
            btn_others.TabIndex = 4;
            btn_others.Text = "Các loại";
            btn_others.Click += btn_others_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btn_maCuaToi);
            panel1.Controls.Add(btn_tatCa);
            panel1.Controls.Add(btn_voucher);
            panel1.Controls.Add(pn_choice);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btn_others);
            panel1.Controls.Add(btn_fast_foods);
            panel1.Controls.Add(btn_drinks);
            panel1.Controls.Add(btn_home);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(129, 845);
            panel1.TabIndex = 5;
            // 
            // btn_maCuaToi
            // 
            btn_maCuaToi.BorderRadius = 10;
            btn_maCuaToi.CustomizableEdges = customizableEdges9;
            btn_maCuaToi.DisabledState.BorderColor = Color.DarkGray;
            btn_maCuaToi.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_maCuaToi.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_maCuaToi.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_maCuaToi.FillColor = Color.Gray;
            btn_maCuaToi.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_maCuaToi.ForeColor = Color.White;
            btn_maCuaToi.Location = new Point(15, 797);
            btn_maCuaToi.Name = "btn_maCuaToi";
            btn_maCuaToi.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btn_maCuaToi.Size = new Size(101, 29);
            btn_maCuaToi.TabIndex = 8;
            btn_maCuaToi.Text = "Mã của tôi";
            btn_maCuaToi.Visible = false;
            btn_maCuaToi.Click += btn_maCuaToi_Click;
            // 
            // btn_tatCa
            // 
            btn_tatCa.BorderRadius = 10;
            btn_tatCa.CustomizableEdges = customizableEdges11;
            btn_tatCa.DisabledState.BorderColor = Color.DarkGray;
            btn_tatCa.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_tatCa.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_tatCa.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_tatCa.FillColor = Color.Red;
            btn_tatCa.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_tatCa.ForeColor = Color.White;
            btn_tatCa.Location = new Point(15, 763);
            btn_tatCa.Name = "btn_tatCa";
            btn_tatCa.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btn_tatCa.Size = new Size(101, 29);
            btn_tatCa.TabIndex = 7;
            btn_tatCa.Text = "Tất cả";
            btn_tatCa.Visible = false;
            btn_tatCa.Click += btn_tatCa_Click;
            // 
            // btn_voucher
            // 
            btn_voucher.BorderRadius = 5;
            btn_voucher.CustomizableEdges = customizableEdges13;
            btn_voucher.DisabledState.BorderColor = Color.DarkGray;
            btn_voucher.DisabledState.CustomBorderColor = Color.DarkGray;
            btn_voucher.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn_voucher.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btn_voucher.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn_voucher.FillColor = Color.White;
            btn_voucher.FillColor2 = Color.White;
            btn_voucher.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_voucher.ForeColor = Color.Black;
            btn_voucher.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            btn_voucher.HoverState.BorderColor = Color.FromArgb(248, 9, 9);
            btn_voucher.HoverState.FillColor = Color.FromArgb(248, 9, 9);
            btn_voucher.HoverState.FillColor2 = Color.FromArgb(248, 9, 9);
            btn_voucher.Image = Properties.Resources.food_other;
            btn_voucher.ImageSize = new Size(36, 35);
            btn_voucher.Location = new Point(9, 653);
            btn_voucher.Margin = new Padding(3, 4, 3, 4);
            btn_voucher.Name = "btn_voucher";
            btn_voucher.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btn_voucher.Size = new Size(111, 111);
            btn_voucher.TabIndex = 4;
            btn_voucher.Text = "Mã giảm giá";
            btn_voucher.Visible = false;
            btn_voucher.Click += btn_voucher_Click;
            // 
            // pn_choice
            // 
            pn_choice.BackColor = Color.Red;
            pn_choice.Location = new Point(123, 205);
            pn_choice.Name = "pn_choice";
            pn_choice.Size = new Size(5, 69);
            pn_choice.TabIndex = 5;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(guna2Panel1);
            guna2ShadowPanel1.Controls.Add(btn_search);
            guna2ShadowPanel1.Controls.Add(tb_search);
            guna2ShadowPanel1.Controls.Add(lb_nameUser1);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(161, 31);
            guna2ShadowPanel1.Margin = new Padding(3, 4, 3, 4);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 20;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(998, 136);
            guna2ShadowPanel1.TabIndex = 6;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2Panel1.AutoRoundedCorners = true;
            guna2Panel1.BackColor = Color.White;
            guna2Panel1.BorderColor = Color.FromArgb(248, 9, 9);
            guna2Panel1.BorderRadius = 39;
            guna2Panel1.BorderThickness = 1;
            guna2Panel1.Controls.Add(lb_nameUser2);
            guna2Panel1.Controls.Add(pictureBox3);
            guna2Panel1.CustomBorderColor = Color.Red;
            guna2Panel1.CustomizableEdges = customizableEdges15;
            guna2Panel1.Location = new Point(758, 33);
            guna2Panel1.Margin = new Padding(3, 4, 3, 4);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Panel1.Size = new Size(206, 80);
            guna2Panel1.TabIndex = 10;
            // 
            // lb_nameUser2
            // 
            lb_nameUser2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lb_nameUser2.AutoSize = true;
            lb_nameUser2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            lb_nameUser2.ForeColor = Color.Black;
            lb_nameUser2.Location = new Point(81, 27);
            lb_nameUser2.Name = "lb_nameUser2";
            lb_nameUser2.Size = new Size(92, 25);
            lb_nameUser2.TabIndex = 1;
            lb_nameUser2.Text = "Hợp Kiên";
            // 
            // pictureBox3
            // 
            pictureBox3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox3.Image = Properties.Resources.user2;
            pictureBox3.Location = new Point(17, 11);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 61);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // btn_search
            // 
            btn_search.Anchor = AnchorStyles.Top;
            btn_search.Image = Properties.Resources.search;
            btn_search.Location = new Point(359, 45);
            btn_search.Margin = new Padding(3, 4, 3, 4);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(32, 32);
            btn_search.SizeMode = PictureBoxSizeMode.AutoSize;
            btn_search.TabIndex = 3;
            btn_search.TabStop = false;
            btn_search.Click += btn_search_Click;
            // 
            // tb_search
            // 
            tb_search.Anchor = AnchorStyles.Top;
            tb_search.BackColor = Color.White;
            tb_search.BorderStyle = BorderStyle.None;
            tb_search.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            tb_search.ForeColor = Color.Black;
            tb_search.Location = new Point(402, 52);
            tb_search.Margin = new Padding(3, 4, 3, 4);
            tb_search.Name = "tb_search";
            tb_search.PlaceholderText = "Tìm kiếm sản phẩm";
            tb_search.Size = new Size(171, 25);
            tb_search.TabIndex = 2;
            // 
            // lb_nameUser1
            // 
            lb_nameUser1.AutoSize = true;
            lb_nameUser1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            lb_nameUser1.Location = new Point(73, 61);
            lb_nameUser1.Name = "lb_nameUser1";
            lb_nameUser1.Size = new Size(120, 32);
            lb_nameUser1.TabIndex = 1;
            lb_nameUser1.Text = "Hợp Kiên";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(73, 33);
            label1.Name = "label1";
            label1.Size = new Size(91, 28);
            label1.TabIndex = 0;
            label1.Text = "Xin chào,";
            // 
            // panel2
            // 
            panel2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel2.BackColor = SystemColors.Control;
            panel2.Controls.Add(lbl_username);
            panel2.Controls.Add(DiemTichLuy);
            panel2.Controls.Add(lb_phoBien);
            panel2.Controls.Add(lb_danhMucPhu);
            panel2.Controls.Add(pb_muiTen);
            panel2.Controls.Add(lb_tatCa);
            panel2.Controls.Add(lb_chonDanhMuc);
            panel2.Controls.Add(flowLayout);
            panel2.Location = new Point(131, 171);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(606, 675);
            panel2.TabIndex = 7;
            // 
            // lbl_username
            // 
            lbl_username.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbl_username.IsDerivedStyle = true;
            lbl_username.Location = new Point(0, 0);
            lbl_username.Name = "lbl_username";
            lbl_username.Size = new Size(201, 36);
            lbl_username.Style = MetroSet_UI.Enums.Style.Light;
            lbl_username.StyleManager = null;
            lbl_username.TabIndex = 7;
            lbl_username.Text = "UserName";
            lbl_username.ThemeAuthor = "Narwin";
            lbl_username.ThemeName = "MetroLite";
            lbl_username.Visible = false;
            lbl_username.Click += lbl_username_Click;
            // 
            // DiemTichLuy
            // 
            DiemTichLuy.BackColor = Color.Transparent;
            DiemTichLuy.Location = new Point(421, 45);
            DiemTichLuy.Name = "DiemTichLuy";
            DiemTichLuy.Point = 0;
            DiemTichLuy.Size = new Size(181, 23);
            DiemTichLuy.TabIndex = 6;
            DiemTichLuy.Visible = false;
            // 
            // lb_phoBien
            // 
            lb_phoBien.AutoSize = true;
            lb_phoBien.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lb_phoBien.ForeColor = Color.Black;
            lb_phoBien.Location = new Point(233, 40);
            lb_phoBien.Name = "lb_phoBien";
            lb_phoBien.Size = new Size(95, 28);
            lb_phoBien.TabIndex = 4;
            lb_phoBien.Text = "Phổ biến";
            // 
            // lb_danhMucPhu
            // 
            lb_danhMucPhu.AutoSize = true;
            lb_danhMucPhu.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lb_danhMucPhu.ForeColor = Color.FromArgb(80, 77, 77);
            lb_danhMucPhu.Location = new Point(233, 0);
            lb_danhMucPhu.Name = "lb_danhMucPhu";
            lb_danhMucPhu.Size = new Size(139, 28);
            lb_danhMucPhu.TabIndex = 3;
            lb_danhMucPhu.Text = "Danh mục phụ";
            // 
            // pb_muiTen
            // 
            pb_muiTen.Image = Properties.Resources.next;
            pb_muiTen.Location = new Point(178, 40);
            pb_muiTen.Margin = new Padding(3, 4, 3, 4);
            pb_muiTen.Name = "pb_muiTen";
            pb_muiTen.Size = new Size(23, 27);
            pb_muiTen.SizeMode = PictureBoxSizeMode.Zoom;
            pb_muiTen.TabIndex = 2;
            pb_muiTen.TabStop = false;
            // 
            // lb_tatCa
            // 
            lb_tatCa.AutoSize = true;
            lb_tatCa.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lb_tatCa.ForeColor = Color.Black;
            lb_tatCa.Location = new Point(34, 40);
            lb_tatCa.Name = "lb_tatCa";
            lb_tatCa.Size = new Size(70, 28);
            lb_tatCa.TabIndex = 1;
            lb_tatCa.Text = "Tất cả";
            // 
            // lb_chonDanhMuc
            // 
            lb_chonDanhMuc.AutoSize = true;
            lb_chonDanhMuc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lb_chonDanhMuc.ForeColor = Color.FromArgb(80, 77, 77);
            lb_chonDanhMuc.Location = new Point(34, 0);
            lb_chonDanhMuc.Name = "lb_chonDanhMuc";
            lb_chonDanhMuc.Size = new Size(149, 28);
            lb_chonDanhMuc.TabIndex = 0;
            lb_chonDanhMuc.Text = "Chọn danh mục";
            // 
            // flowLayout
            // 
            flowLayout.AutoScroll = true;
            flowLayout.BackColor = SystemColors.Control;
            flowLayout.Location = new Point(0, 75);
            flowLayout.Margin = new Padding(3, 4, 3, 4);
            flowLayout.Name = "flowLayout";
            flowLayout.Size = new Size(603, 600);
            flowLayout.TabIndex = 5;
            flowLayout.Paint += flowLayout_Paint;
            // 
            // flowpanel_order_history
            // 
            flowpanel_order_history.AutoScroll = true;
            flowpanel_order_history.BackColor = SystemColors.Control;
            flowpanel_order_history.Location = new Point(8, 181);
            flowpanel_order_history.Name = "flowpanel_order_history";
            flowpanel_order_history.Size = new Size(472, 501);
            flowpanel_order_history.TabIndex = 5;
            flowpanel_order_history.Visible = false;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            panel3.BackColor = SystemColors.Control;
            panel3.Controls.Add(flowpanel_order_history);
            panel3.Controls.Add(flowLayoutItemOder);
            panel3.Controls.Add(ThanhToan);
            panel3.Controls.Add(guna2Panel2);
            panel3.Controls.Add(cbb_payment);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(738, 171);
            panel3.Margin = new Padding(0);
            panel3.Name = "panel3";
            panel3.Size = new Size(478, 675);
            panel3.TabIndex = 6;
            // 
            // flowLayoutItemOder
            // 
            flowLayoutItemOder.AutoScroll = true;
            flowLayoutItemOder.Location = new Point(7, 181);
            flowLayoutItemOder.Margin = new Padding(3, 4, 3, 4);
            flowLayoutItemOder.Name = "flowLayoutItemOder";
            flowLayoutItemOder.Size = new Size(469, 212);
            flowLayoutItemOder.TabIndex = 4;
            // 
            // ThanhToan
            // 
            ThanhToan.AutoSize = true;
            ThanhToan.DiemTichLuy = 0;
            ThanhToan.Location = new Point(8, 397);
            ThanhToan.Margin = new Padding(0);
            ThanhToan.Name = "ThanhToan";
            ThanhToan.Size = new Size(458, 369);
            ThanhToan.TabIndex = 0;
            ThanhToan.TienThanhToan = 0;
            ThanhToan.TienVoucher = 0;
            ThanhToan.TongTien = 0;
            ThanhToan.Click += select_Mua;
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.FromArgb(248, 9, 9);
            guna2Panel2.BorderColor = Color.FromArgb(248, 9, 9);
            guna2Panel2.BorderRadius = 10;
            guna2Panel2.BorderThickness = 1;
            guna2Panel2.Controls.Add(pictureBox9);
            guna2Panel2.Controls.Add(lb_paydate);
            guna2Panel2.Controls.Add(label6);
            guna2Panel2.CustomizableEdges = customizableEdges17;
            guna2Panel2.Location = new Point(23, 91);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2Panel2.Size = new Size(433, 84);
            guna2Panel2.TabIndex = 3;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.shopping_cart;
            pictureBox9.Location = new Point(312, 8);
            pictureBox9.Margin = new Padding(3, 4, 3, 4);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(114, 67);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 2;
            pictureBox9.TabStop = false;
            // 
            // lb_paydate
            // 
            lb_paydate.AutoSize = true;
            lb_paydate.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lb_paydate.ForeColor = Color.White;
            lb_paydate.Location = new Point(39, 47);
            lb_paydate.Name = "lb_paydate";
            lb_paydate.Size = new Size(96, 23);
            lb_paydate.TabIndex = 1;
            lb_paydate.Text = "18/08/2023";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(39, 8);
            label6.Name = "label6";
            label6.Size = new Size(118, 32);
            label6.TabIndex = 0;
            label6.Text = "Đặt hàng";
            // 
            // cbb_payment
            // 
            cbb_payment.BackColor = Color.Transparent;
            cbb_payment.CustomizableEdges = customizableEdges19;
            cbb_payment.DrawMode = DrawMode.OwnerDrawFixed;
            cbb_payment.DropDownStyle = ComboBoxStyle.DropDownList;
            cbb_payment.FillColor = SystemColors.Control;
            cbb_payment.FocusedColor = SystemColors.Control;
            cbb_payment.FocusedState.BorderColor = SystemColors.Control;
            cbb_payment.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbb_payment.ForeColor = Color.Black;
            cbb_payment.ItemHeight = 30;
            cbb_payment.Items.AddRange(new object[] { "Thanh toán", "Tiền mặt", "Thẻ NH", "Momo", "Zalopay" });
            cbb_payment.Location = new Point(54, 23);
            cbb_payment.Name = "cbb_payment";
            cbb_payment.ShadowDecoration.CustomizableEdges = customizableEdges20;
            cbb_payment.Size = new Size(141, 36);
            cbb_payment.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cbb_payment.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.Controls.Add(lb_history);
            panel4.Controls.Add(pictureBox8);
            panel4.Controls.Add(lb_oder);
            panel4.Controls.Add(pictureBox7);
            panel4.Controls.Add(pictureBox6);
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(475, 84);
            panel4.TabIndex = 0;
            // 
            // lb_history
            // 
            lb_history.AutoSize = true;
            lb_history.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lb_history.Location = new Point(394, 29);
            lb_history.Name = "lb_history";
            lb_history.Size = new Size(58, 20);
            lb_history.TabIndex = 4;
            lb_history.Text = "Lịch sử";
            lb_history.Click += showOrderHistory;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.history;
            pictureBox8.Location = new Point(347, 19);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(40, 40);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            pictureBox8.Click += showOrderHistory;
            // 
            // lb_oder
            // 
            lb_oder.AutoSize = true;
            lb_oder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lb_oder.Location = new Point(261, 29);
            lb_oder.Name = "lb_oder";
            lb_oder.Size = new Size(77, 20);
            lb_oder.TabIndex = 2;
            lb_oder.Text = "Đơn hàng";
            lb_oder.Click += click_order;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.checklist;
            pictureBox7.Location = new Point(214, 19);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(40, 40);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 1;
            pictureBox7.TabStop = false;
            pictureBox7.Click += click_order;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.pay;
            pictureBox6.Location = new Point(8, 19);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(40, 40);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // HomeForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1216, 845);
            Controls.Add(panel3);
            Controls.Add(guna2ShadowPanel1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Margin = new Padding(3, 4, 3, 4);
            MinimumSize = new Size(1232, 800);
            Name = "HomeForm";
            Text = "Circle K";
            Load += HomeForm_Load;
            SizeChanged += HomeForm_SizeChanged;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)btn_search).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pb_muiTen).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2GradientTileButton btn_home;
        private Guna.UI2.WinForms.Guna2GradientTileButton btn_drinks;
        private Guna.UI2.WinForms.Guna2GradientTileButton btn_fast_foods;
        private Guna.UI2.WinForms.Guna2GradientTileButton btn_others;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label lb_nameUser1;
        private Label label1;
        private PictureBox btn_search;
        private TextBox tb_search;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label lb_nameUser2;
        private PictureBox pictureBox3;
        private Panel panel2;
        private Label lb_chonDanhMuc;
        private FlowLayoutPanel flowLayout;
        private Label lb_phoBien;
        private Label lb_danhMucPhu;
        private PictureBox pb_muiTen;
        private Label lb_tatCa;
        private Panel panel3;
        private Panel panel4;
        private PictureBox pictureBox6;
        private ListBox listBox1;
        private MetroSet_UI.Controls.MetroSetListBox metroSetListBox2;
        private ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_payment;
        private PictureBox pictureBox7;
        private Label lb_oder;
        private Label lb_history;
        private PictureBox pictureBox8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private PictureBox pictureBox9;
        private Label lb_paydate;
        private Label label6;
        private FlowLayoutPanel flowLayoutItemOder;
        private Panel pn_choice;
        private Guna.UI2.WinForms.Guna2GradientTileButton btn_voucher;
        private Guna.UI2.WinForms.Guna2Button btn_maCuaToi;
        private Guna.UI2.WinForms.Guna2Button btn_tatCa;
        private DiemTichLuy DiemTichLuy;
        private ThanhToan ThanhToan;
        private FlowLayoutPanel flowpanel_order_history;
        private MetroSet_UI.Controls.MetroSetLabel lbl_username;
    }
}